---@meta _
---@diagnostic disable: duplicate-doc-field

-- Hub de gestion (NUI) : remplace la navigation VUI "GESTION DE GLOBAL" > "BUILDERS"
-- par une grille de catégories. Un clic sur une catégorie ouvre un sous-menu de tuiles
-- dans le hub (comme les builders). Un outil VUI s'ouvre DANS le hub (VUI.OpenInHub) :
-- le NUI VUI n'est pas affiché, les messages sont relayés via "vui:hub:message".
--
-- Les groupes de builders sont générés depuis StaffMenu.builderEntries
-- (buildersMenu.lua) : un séparateur = une catégorie, les boutons qui suivent = ses outils.

--- Une fonction reçue d'une autre ressource (ex. `menu.open` créé par l'export VUI
--- CreateSubMenu) n'est pas de type "function" mais une table appelable (funcref).
---@param f any
---@return boolean
local function IsCallable(f)
    if type(f) == "function" then return true end
    if type(f) == "table" then
        local mt = getmetatable(f)
        return mt ~= nil and mt.__call ~= nil
    end
    return false
end

-- Appel avec `:` obligatoire : le proxy d'exports FiveM est `function(self, ...)`,
-- un appel avec `.` décale les arguments (openFn devient self).
local function OpenVuiInHub(openFn, returnFn)
    if not IsCallable(openFn) then return false, "fonction d'ouverture absente" end

    local ok, err = pcall(function()
        exports["VUI"]:OpenInHub(openFn, returnFn)
    end)
    if not ok then return false, err end

    local modeOk, inHub = pcall(function()
        return exports["VUI"]:IsHubMode()
    end)
    if not modeOk or inHub ~= true then
        return false, "le menu ne s'est pas ouvert"
    end
    return true
end

local hubOpen = false
local hubMinimized = false
local hubData = nil
local hubTextInput = nil
local hubVuiOpenSerial = 0
local hubVuiReadySerial = 0

local function HasPerm(perms, need)
    if VFW.HasStaffPerm then
        if not need then return true end
        if type(need) == "string" then return VFW.HasStaffPerm(need) end
        if type(need) == "table" then
            for i = 1, #need do
                if VFW.HasStaffPerm(need[i]) then return true end
            end
            return false
        end
    end
    local role = VFW.PlayerGlobalData and VFW.PlayerGlobalData.role
    if role == "niveau_6" then return true end
    if not need then return true end
    if type(need) == "string" then return perms[need] == true end
    if type(need) == "table" then
        for i = 1, #need do
            if perms[need[i]] then return true end
        end
    end
    return false
end

-- Catégories du hub (sous-menus en tuiles, comme les builders).
-- items.submenu = clé StaffMenu ; items.action = action Lua locale ; items.perm = permission extra.
local directCategories = {
    {
        id = "permissions", label = "PERMISSIONS", icon = "key", perm = "gestion_perm",
        items = {
            { label = "Rôles staff", desc = "Créer, modifier et attribuer les rôles et permissions", icon = "lock", action = "roles_panel", opens = "roles" },
        },
    },
    {
        id = "serveur", label = "SERVEUR", icon = "wrench", perm = { "server_management", "dev" },
        items = {
            { label = "Configuration serveur", desc = "Nom, Discord, et une couleur qui change toute la charte", icon = "palette", opens = "branding" },
            { label = "Loading screen", desc = "Vidéo ou image de fond, musique d’attente — visible à la connexion", icon = "film", opens = "loadingscreen" },
            { label = "Création de personnage", desc = "Musique de l’écran, nombre de slots, slot VIP, suppression", icon = "users", opens = "charcreator" },
            { label = "Tablette météo", desc = "Zones météo autour de toi ou sur la carte", icon = "globe", perm = "server_management", action = "weather_tablet", opens = "weather" },
            { label = "Météo, heure et stats", desc = "Heure, gel du temps, statistiques serveur", icon = "clock", perm = "server_management", action = "server_panel", opens = "server" },
            { label = "Nettoyer la zone", desc = "Supprimer véhicules, peds et objets autour de vous", icon = "trash", perm = "clean_zone", action = "clear_zone" },
            { label = "Densité du monde", desc = "PNJ, trafic et véhicules garés — appliqué en direct à tous", icon = "globe", perm = "server_management", opens = "dev", dev = "density" },
            { label = "Zones de circulation", desc = "Limites de vitesse par zone : voir, créer, modifier, supprimer", icon = "car", perm = "server_management", opens = "dev", dev = "traffic" },
            { label = "Gérer les images", desc = "Logo, bannière, pause, items, sociétés, mugshots", icon = "image", opens = "images" },
            { label = "Notifications périodiques", desc = "Notifications automatiques", icon = "megaphone", opens = "notifs" },
            { label = "Starter pack", desc = "Argent et items de départ des nouveaux joueurs", icon = "gift", opens = "dev", dev = "starterpack" },
            { label = "Staff logs", desc = "Logs envoyés et file d'attente", icon = "report", perm = "staff_logs", opens = "dev", dev = "stafflogs" },
            { label = "Webhooks logs", desc = "Webhooks Discord par type de log", icon = "report", opens = "dev", dev = "webhooks" },
            { label = "Gestion téléphone", desc = "Messages, mails, posts, certifications d'un numéro", icon = "chat", perm = "wipe", opens = "dev", dev = "phone" },
            { label = "Donner à tous", desc = "Items ou argent à tous les joueurs connectés", icon = "gift", perm = "gestion_items", opens = "dev", dev = "giveall" },
            { label = "Bypass cooldown", desc = "Cooldowns des commandes staff et joueurs exemptés", icon = "clock", opens = "dev", dev = "cooldown" },
            { label = "Antiban", desc = "Joueurs protégés contre ban / kick", icon = "shield", opens = "dev", dev = "antiban" },
            { label = "Reset sanctions", desc = "Supprimer l'historique de sanctions d'un joueur", icon = "trash", opens = "dev", dev = "sanctions" },
            { label = "Restauration inventaire", desc = "Restaurer un inventaire confisqué", icon = "refresh", perm = "restore_inventory", opens = "dev", dev = "invrestore" },
        },
    },
    {
        id = "interim", label = "INTÉRIM", icon = "briefcase", perm = { "builder_interim_economy", "server_management", "dev" },
        items = {
            { label = "Gestion de l'intérim", desc = "Métiers, points et PNJ, réglages, centre d'emploi", icon = "briefcase", opens = "dev", dev = "interim" },
        },
    },
    {
        id = "scratch", label = "TICKETS À GRATTER", icon = "gift", perm = { "builder_scratch_card", "server_management", "dev" },
        items = {
            { label = "Gains et probabilités", desc = "Montants gagnés et pourcentage de chance de chaque palier", icon = "gift", opens = "dev", dev = "scratch" },
        },
    },
    {
        id = "videos", label = "VIDÉOS", icon = "play", perm = "video_management",
        items = {
            { label = "Gestion des vidéos", desc = "Lien YouTube, cible, plein écran, lancer / arrêter", icon = "film", action = "videos_panel", opens = "videos", intent = "manage" },
            { label = "Diffuser à tous", desc = "Lancer une vidéo YouTube pour tout le serveur", icon = "monitor", action = "videos_panel", opens = "videos", intent = "broadcast" },
            { label = "Arrêter pour tous", desc = "Couper toutes les vidéos en cours", icon = "close", action = "videos_panel", opens = "videos", intent = "stop" },
        },
    },
    {
        id = "inventaire", label = "INVENTAIRE", icon = "bag", perm = { "dev", "gestion_items" },
        items = {
            { label = "Items", desc = "Créer, modifier et supprimer les items", icon = "box", perm = "gestion_items", opens = "dev", dev = "items" },
            { label = "Poids des joueurs", desc = "Poids max personnalisé par joueur", icon = "scales", opens = "dev", dev = "weight" },
            { label = "Poids des sacs", desc = "Poids max par modèle de sac", icon = "bag", opens = "dev", dev = "bags" },
            { label = "Plaques GPB", desc = "Autoriser ou bloquer les plaques par GPB", icon = "shield", opens = "dev", dev = "gpb" },
            { label = "Potions", desc = "Donner des potions de farm", icon = "flask", opens = "dev", dev = "potions" },
            { label = "Véhicule blacklist", desc = "Bloquer le spawn de modèles", icon = "ban", opens = "dev", dev = "vehblacklist" },
        },
    },
    {
        id = "dev", label = "DÉVELOPPEURS", icon = "monitor", perm = "dev",
        items = {
            { label = "Options développeur", desc = "Mode développeur, print props & entities, poids développeur", icon = "settings", opens = "dev", dev = "devstate" },
            { label = "Création de caméra", desc = "Freecam, flou, effets, FOV, export / import de configuration", icon = "camera", opens = "dev", dev = "camera" },
            { label = "Liste des véhicules", desc = "Parcourir, prévisualiser et spawn les véhicules", icon = "car", opens = "dev", dev = "carlist" },
            { label = "Animation manager", desc = "Activer, renommer, déplacer les animations", icon = "film", perm = "manage_anim", opens = "dev", dev = "animmanager" },
            { label = "Ajouter une animation", desc = "Créer, modifier ou supprimer une animation, marche ou expression personnalisée", icon = "plus", perm = "manage_anim", action = "anims_panel", opens = "anims" },
            { label = "Appliquer une taille", desc = "Modifier la taille du ped d'un joueur", icon = "ruler", opens = "dev", dev = "pedscale" },
            { label = "Print coords", desc = "Afficher les coordonnées dans F8", icon = "pin", action = "print_coords" },
            { label = "Print ground coords", desc = "Coordonnées au sol dans F8", icon = "pin", action = "print_ground" },
            { label = "Prop placer", desc = "Placement d'objets sur le ped (gizmo)", icon = "ruler", opens = "dev", dev = "propplacer" },
            { label = "Liste des mappings", desc = "Mappings de la carte (mode développeur)", icon = "map", opens = "dev", dev = "mappings" },
        },
    },
    {
        id = "events", label = "EVENTS SPÉCIAUX", icon = "rocket", perm = "events",
        items = {
            { label = "Blackout", desc = "Couper ou rétablir les éclairages de la ville", icon = "bolt", action = "blackout" },
            { label = "Incendie", desc = "Créer et gérer des incendies", icon = "fire", submenu = "fireMenu" },
            { label = "Feu d'artifice", desc = "Lancer un spectacle pyrotechnique", icon = "sparkles", submenu = "fireworkMenu" },
            { label = "Séisme", desc = "Déclencher un séisme", icon = "globe", submenu = "earthquakeMenu" },
        },
    },
}

-- Lookup des tuiles des catégories directes (rempli par BuildHubData)
local directItemLookup = {}

--- Sépare le jeton d'icône (":car: GO FAST" -> "car", "GO FAST").
---@param label string
---@return string icon, string text
local function SplitLabel(label)
    label = tostring(label or "")
    local icon = label:match("^%s*:([%w%-]+):")
    local text = label:gsub(":[%w%-]+:", "")
    text = text:gsub("^%s+", ""):gsub("%s+$", "")
    -- "CATÉGORIE BRAQUAGES" -> "BRAQUAGES"
    text = text:gsub("^CATÉGORIE%s+", ""):gsub("^CATEGORIE%s+", "")
    return icon or "grid", text
end

--- Construit les données du hub filtrées par les permissions du joueur.
---@return table categories
local function BuildHubData()
    local perms = (VFW.PlayerGlobalData and VFW.PlayerGlobalData.permissions) or {}
    local categories = {}
    directItemLookup = {}

    for i = 1, #directCategories do
        local c = directCategories[i]
        if HasPerm(perms, c.perm) then
            local group = { id = c.id, kind = "group", label = c.label, icon = c.icon, items = {} }
            local lookup = {}
            for n = 1, #(c.items or {}) do
                local item = c.items[n]
                if HasPerm(perms, item.perm) and (not item.submenu or StaffMenu[item.submenu]) then
                    local slot = #group.items + 1
                    lookup[slot] = item
                    group.items[slot] = {
                        index = slot, label = item.label, desc = item.desc or "", icon = item.icon or "grid",
                        opens = item.opens or (item.action and "action" or "vui"),
                        intent = item.intent,
                        dev = item.dev,
                    }
                end
            end
            if #group.items > 0 then
                directItemLookup[c.id] = lookup
                categories[#categories + 1] = group
            end
        end
    end

    if perms["builder_menu"] and StaffMenu.builderEntries then
        local entries = StaffMenu.builderEntries
        local group = nil

        for i = 1, #entries do
            local e = entries[i]
            if e.separator then
                if HasPerm(perms, e.perm) then
                    local icon, text = SplitLabel(e.separator)
                    group = { id = "group_" .. i, kind = "group", label = text, icon = icon, items = {} }
                    categories[#categories + 1] = group
                else
                    group = nil
                end
            elseif group and e.label and not e.hubHidden and (HasPerm(perms, e.perm) or (e.altPerm and perms[e.altPerm])) then
                local icon, text = SplitLabel(e.label)
                group.items[#group.items + 1] = {
                    index = i, label = text, desc = e.desc or "", icon = icon,
                    opens = e.opens or ((e.submenu or e.openFn) and "vui" or "action"),
                }
            end
        end

        -- Retirer les groupes vides (aucun outil accessible)
        for i = #categories, 1, -1 do
            local c = categories[i]
            if c.kind == "group" and #c.items == 0 then
                table.remove(categories, i)
            end
        end
    end

    return categories
end

--- Dit à VUI si le hub est à l'écran (voir VUI_HubVisible dans VUI/vui.lua).
---@param visible boolean
local function SetVuiHubVisible(visible)
    -- Pas de pcall muet : si l'export manque (VUI pas à jour), le menu VUI se remettrait à
    -- s'afficher derrière le hub sans qu'on sache pourquoi. On veut le voir.
    local ok, err = pcall(function() exports["VUI"]:SetHubVisible(visible) end)
    if not ok then
        console.error("[GestionHub] VUI:SetHubVisible indisponible : " .. tostring(err))
    end
end

--- Ouvre le hub. `state.category` = catégorie à rouvrir (retour depuis un outil).
---@param state? table
function StaffMenu.OpenGestionHub(state)
    if not VFW.HasStaffPerm("gestion") then
        VFW.ShowNotification({ type = 'STAFF', variant = 'ERROR', subtitle = 'Gestion', message = "Vous n'avez pas la permission d'accéder à la gestion." })
        return
    end

    -- Le hub prend la main : on ferme tout menu VUI encore affiché.
    exports["VUI"]:CloseAll()

    hubData = BuildHubData()
    hubOpen = true
    hubMinimized = false
    -- Tant que le hub est affiché, VUI ne doit plus rendre ses menus dans son propre
    -- overlay : ils apparaîtraient par-dessus la page du hub (l'ancien menu qui revient).
    SetVuiHubVisible(true)

    SendNUIMessage({
        action = "gestion:open",
        data = {
            brand = VFW.BrandName(),
            categories = hubData,
            state = state,
        },
    })
    VFW.Nui.Focus(true)
end

function StaffMenu.CloseGestionHub()
    if not hubOpen then return end
    hubOpen = false
    hubMinimized = false
    SetVuiHubVisible(false)
    if hubTextInput == nil then
        hubTextInput = false
    end
    -- Nettoyage des outils natifs (previews, freecam, skin...) — gestion_dev.lua
    TriggerEvent("gestion:hub:closed")
    -- Coupe un éventuel menu VUI encore rendu dans le hub
    exports["VUI"]:CloseAll()
    -- Force la fermeture complète de l'overlay NUI et désactiver le curseur.
    -- nui:visible false cachait tout le HUD (faim, vie, compteur, staff) et le
    -- callback plantait ensuite, donc rien ne le réaffichait.
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
    SendNUIMessage({ action = "gestion:close" })
    VFW.Nui.Focus(false)
    VFW.Nui.Visible(true)
    if VFW.Nui.HudVisible then
        VFW.Nui.HudVisible(true)
    end
end

function StaffMenu.IsGestionHubOpen()
    return hubOpen == true
end

function StaffMenu.IsGestionHubMinimized()
    return hubOpen == true and hubMinimized == true
end

--- Affiche une notification au-dessus de la tablette Gestion.
--- Retourne true lorsque la notification a été prise en charge par le hub.
function StaffMenu.ShowGestionNotification(notification)
    if not hubOpen or hubMinimized or type(notification) ~= "table" then
        return false
    end

    SendNUIMessage({
        action = "gestion:toast",
        data = notification,
    })
    return true
end

local function ApplyWalkFocus()
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
end

function StaffMenu.MinimizeGestionHub()
    if not hubOpen or hubMinimized then return end
    hubMinimized = true
    -- Hub réduit : le joueur marche et peut ouvrir n'importe quel menu VUI (commerce,
    -- métier…). Ceux-là doivent retrouver l'overlay VUI, pas la page du hub.
    SetVuiHubVisible(false)
    SendNUIMessage({ action = "gestion:minimize" })
    ApplyWalkFocus()
end

function StaffMenu.RestoreGestionHub()
    if not hubOpen then return end
    hubMinimized = false
    SetVuiHubVisible(true)
    SendNUIMessage({ action = "gestion:restore" })
    VFW.Nui.Focus(true)
end

function StaffMenu.CoverGestionHub()
    if not hubOpen then return end
    hubMinimized = false
    SendNUIMessage({ action = "gestion:cover" })
end

function StaffMenu.UncoverGestionHub()
    if not hubOpen then return end
    SendNUIMessage({ action = "gestion:uncover" })
    if hubMinimized then
        ApplyWalkFocus()
    else
        VFW.Nui.Focus(true)
    end
end

--- Saisie « dans le monde » (placer des points, viser un endroit...) lancée depuis un menu VUI.
---
--- Dans le hub de gestion, menu.close() TERMINE la chaîne de menus : le hub revient à la liste des outils et
--- le menu rouvert ensuite n'est plus affiché (appuyer sur « Spawn des véhicules » renvoyait à la liste des
--- outils). On garde donc le menu ouvert, on cache le hub et on rend les contrôles au jeu. Les touches de VUI
--- sont inactives en mode hub : Entrée et Retour ne touchent pas au menu pendant la saisie.
--- Hors du hub (menu F5), comportement d'origine : on ferme le menu, on saisit, on le rouvre.
---@param menu table Le menu VUI qui lance la saisie
---@param fn fun(): any La saisie (peut attendre) ; sa valeur de retour est rendue
---@return any
function StaffMenu.PlaceInWorld(menu, fn)
    if StaffMenu.IsGestionHubOpen() then
        -- Hub déjà réduit par le joueur : il marche déjà, rien à cacher.
        if StaffMenu.IsGestionHubMinimized() then return fn() end

        StaffMenu.CoverGestionHub()
        VFW.Nui.Focus(false)
        local ok, result = pcall(fn)
        if StaffMenu.IsGestionHubOpen() then
            StaffMenu.UncoverGestionHub()
        end
        if not ok then error(result, 0) end
        return result
    end

    menu.close()
    local ok, result = pcall(fn)
    menu.open()
    if not ok then error(result, 0) end
    return result
end

--- Recolle le focus NUI sur le hub après un clavier / choix (sinon le curseur est perdu).
function StaffMenu.RestoreGestionHubFocus()
    if not hubOpen then return end
    if hubMinimized then
        ApplyWalkFocus()
        return
    end
    VFW.Nui.Focus(true)
end

--- Relais des messages VUI (mode hub) vers le NUI de gestion.
local function ResetHubVuiLoading(reason)
    -- Le front passe en `loading` dès le clic. Sans message de fermeture, une erreur
    -- Lua/VUI le laisserait définitivement sur « Chargement du menu… ».
    SendNUIMessage({
        action = "gestion:vui",
        data = { action = "vui:menu:close" },
    })

    if reason and reason ~= "" then
        StaffMenu.ShowGestionNotification({
            type = 'STAFF',
            variant = 'ERROR',
            subtitle = 'Gestion',
            message = "Ce menu n'a pas pu être chargé. Réessayez.",
        })
        console.error("[GestionHub] " .. tostring(reason))
    end
end

local function RelayVuiToHub(msg)
    if not hubOpen then return end
    if type(msg) == "table" and msg.action ~= "vui:menu:close" then
        hubVuiReadySerial = hubVuiOpenSerial
    end
    SendNUIMessage({ action = "gestion:vui", data = msg })
end

AddEventHandler("vui:hub:message", RelayVuiToHub)
exports("GestionHubVuiMessage", RelayVuiToHub)

AddEventHandler("vui:hub:ended", function()
    if not hubOpen then return end
    ResetHubVuiLoading()
    StaffMenu.RestoreGestionHubFocus()
end)

AddEventHandler("vui:hub:focus", function()
    StaffMenu.RestoreGestionHubFocus()
end)

-- Retour commun des boutons de validation incomplets. Le système VUI ajoute la
-- raison à tous les boutons Créer / Ajouter / Valider / Sauvegarder du hub.
AddEventHandler("vui:validation:blocked", function(reason)
    if not hubOpen then return end
    StaffMenu.ShowGestionNotification({
        type = 'STAFF',
        variant = 'ERROR',
        subtitle = 'Gestion',
        message = tostring(reason or "Complétez les champs obligatoires du formulaire.")
    })
end)

local OpenFromHub

--- Actions locales (clavier, tablettes, toggles) — pas de menu VUI.
---@param action string
local function RunHubAction(action)
    if action == "roles_panel" or action == "server_panel" or action == "weather_tablet" or action == "videos_panel" then
        return
    elseif action == "clear_zone" then
        local radius = tonumber(VFW.Nui.KeyboardInput(true, "Radius (mètres)", "100"))
        if radius and radius > 0 then
            TriggerServerEvent("vfw:staff:clearZone", radius)
        end
    elseif action == "print_coords" then
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local heading = GetEntityHeading(ped)
        print(string.format("^2Coordonnées:^0 x=%.2f, y=%.2f, z=%.2f, heading=%.2f", coords.x, coords.y, coords.z, heading))
        print(string.format("^3Vector3:^0 vector3(%.2f, %.2f, %.2f)", coords.x, coords.y, coords.z))
        print(string.format("^3Vector4:^0 vector4(%.2f, %.2f, %.2f, %.2f)", coords.x, coords.y, coords.z, heading))
        VFW.ShowNotification({ type = 'STAFF', variant = 'SUCCESS', subtitle = 'Outils Dev', message = "Coordonnées affichées dans la console F8." })
    elseif action == "print_ground" then
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local heading = GetEntityHeading(ped)
        local found, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z, false)
        if found then coords = vector3(coords.x, coords.y, groundZ) end
        print(string.format("^2Coordonnées Sol:^0 x=%.2f, y=%.2f, z=%.2f, heading=%.2f", coords.x, coords.y, coords.z, heading))
        print(string.format("^3Vector3:^0 vector3(%.2f, %.2f, %.2f)", coords.x, coords.y, coords.z))
        print(string.format("^3Vector4:^0 vector4(%.2f, %.2f, %.2f, %.2f)", coords.x, coords.y, coords.z, heading))
        VFW.ShowNotification({ type = 'STAFF', variant = 'SUCCESS', subtitle = 'Outils Dev', message = "Coordonnées du sol affichées dans la console F8." })
    elseif action == "ped_scale" then
        local idInput = VFW.Nui.KeyboardInput(true, "ID du joueur cible", "")
        if not idInput or idInput == "" then return end
        local targetId = tonumber(idInput)
        if not targetId then
            VFW.ShowNotification({ type = 'STAFF', variant = 'ERROR', subtitle = 'Outils Dev', message = "Cet identifiant n'est pas valide." })
            return
        end
        local scaleInput = VFW.Nui.KeyboardInput(true, "Taille du ped (0.1 - 2.0)", "1.0")
        if not scaleInput or scaleInput == "" then return end
        local scale = tonumber((scaleInput:gsub(",", ".")))
        if not scale then
            VFW.ShowNotification({ type = 'STAFF', variant = 'ERROR', subtitle = 'Outils Dev', message = "Cette valeur n'est pas valide." })
            return
        end
        local success, applied = TriggerServerCallback("vfw:staff:applyPedScale", targetId, scale)
        if success then
            VFW.ShowNotification({ type = 'STAFF', variant = 'SUCCESS', subtitle = 'Outils Dev', message = "Taille " .. tostring(applied) .. " appliquée sur [" .. targetId .. "]" })
        else
            VFW.ShowNotification({ type = 'STAFF', variant = 'ERROR', subtitle = 'Outils Dev', message = "Impossible d'appliquer la taille." })
        end
    elseif action == "video_all" then
        local videoUrl = VFW.Nui.KeyboardInput(true, "Lien YouTube pour diffusion générale", "")
        if videoUrl and videoUrl ~= "" then
            if string.find(videoUrl, "youtube.com") or string.find(videoUrl, "youtu.be") then
                TriggerServerEvent("vfw:staff:playVideo", videoUrl, 2, 3, -1)
            else
                VFW.ShowNotification({ type = 'STAFF', variant = 'ERROR', subtitle = 'Gestion Vidéos', message = "Ce lien n'est pas valide, YouTube uniquement." })
            end
        end
    elseif action == "video_stop_all" then
        local confirm = VFW.Nui.KeyboardInput(true, "Tapez 'CONFIRMER' pour arrêter toutes les vidéos", "")
        if confirm and string.lower(confirm) == "confirmer" then
            TriggerServerEvent("vfw:staff:stopVideoForAll")
            VFW.ShowNotification({ type = 'STAFF', variant = 'SUCCESS', subtitle = 'Gestion Vidéos', message = "Toutes les vidéos arrêtées." })
        else
            VFW.ShowNotification({ type = 'STAFF', variant = 'ERROR', subtitle = 'Gestion Vidéos', message = "Action annulée." })
        end
    elseif action == "blackout" then
        TriggerServerEvent("vfw:staff:setBlackout", GlobalState.blackout ~= true)
    elseif action == "periodic_notif" then
        OpenPeriodicNotificationsPanel()
    elseif action == "image_manager" then
        StaffMenu.CoverGestionHub()
        StaffMenu.OpenImageManager()
    elseif action == "garage_spawns" then
        OpenFromHub(nil, function()
            StaffMenu.OpenGarageSpawnPointsBuilder()
        end)
    elseif action == "toggle_dev" then
        StaffMenu.isInDevMode = not StaffMenu.isInDevMode
        VFW.ShowNotification({
            type = 'STAFF', variant = StaffMenu.isInDevMode and 'SUCCESS' or 'INFO', subtitle = 'Outils Dev',
            message = StaffMenu.isInDevMode and "Mode développeur activé." or "Mode développeur désactivé.",
        })
    elseif action == "toggle_print_props" then
        StaffMenu.PrintPropsAndEntities = not StaffMenu.PrintPropsAndEntities
        VFW.ShowNotification({
            type = 'STAFF', variant = StaffMenu.PrintPropsAndEntities and 'SUCCESS' or 'INFO', subtitle = 'Outils Dev',
            message = StaffMenu.PrintPropsAndEntities and "Print Props & Entities activé." or "Print Props & Entities désactivé.",
        })
    elseif action == "toggle_dev_weight" then
        StaffMenu.hasDevWeight = not StaffMenu.hasDevWeight
        TriggerServerEvent("vfw:staff:toggleDevWeight", StaffMenu.hasDevWeight)
        VFW.ShowNotification({
            type = 'STAFF', variant = StaffMenu.hasDevWeight and 'SUCCESS' or 'INFO', subtitle = 'Outils Dev',
            message = StaffMenu.hasDevWeight and "Poids développeur activé (5000 kg)." or "Poids développeur désactivé.",
        })
    end
end

--- Ouvre un sous-menu VUI dans le hub (sans fermer le NUI de gestion).
---@param menu table|nil Menu VUI (StaffMenu.xxx)
---@param onClick function|nil Callback du bouton d'origine (exécuté avant l'ouverture)
---@param state table État du hub à restaurer si le hub a été fermé entre-temps
OpenFromHub = function(menu, onClick, state)
    local hasMenu = menu and IsCallable(menu.open)

    if not hasMenu then
        -- Outil externe (tablette, menu hors VUI) : le hub cède la place
        StaffMenu.CloseGestionHub()
        if onClick then
            local ok, err = pcall(onClick)
            if not ok then
                console.error("[GestionHub] onClick error: " .. tostring(err))
            end
        end
        return
    end

    if onClick then
        local ok, err = pcall(onClick)
        if not ok then
            console.error("[GestionHub] onClick error: " .. tostring(err))
            ResetHubVuiLoading("Erreur avant l'ouverture : " .. tostring(err))
            return
        end
    end

    hubVuiOpenSerial = hubVuiOpenSerial + 1
    local serial = hubVuiOpenSerial
    hubVuiReadySerial = 0

    SetTimeout(0, function()
        if not hubOpen then return end
        local opened, err = OpenVuiInHub(menu.open, function()
            if hubOpen then
                StaffMenu.RestoreGestionHubFocus()
            else
                StaffMenu.OpenGestionHub(state)
            end
        end)

        if not opened then
            if serial == hubVuiOpenSerial then
                ResetHubVuiLoading("Ouverture VUI impossible : " .. tostring(err))
            end
            return
        end

        -- Garde-fou pour les menus qui s'ouvrent sans jamais envoyer leur premier rendu.
        SetTimeout(5000, function()
            if hubOpen and serial == hubVuiOpenSerial and hubVuiReadySerial ~= serial then
                pcall(function() exports["VUI"]:CloseAll() end)
                ResetHubVuiLoading("Aucune réponse du menu après 5 secondes")
            end
        end)
    end)
end

RegisterNuiCallback("gestion:close", function(_, cb)
    StaffMenu.CloseGestionHub()
    cb({})
end)

RegisterNuiCallback("gestion:minimize", function(_, cb)
    cb({})
    StaffMenu.MinimizeGestionHub()
end)

RegisterNuiCallback("gestion:restore", function(_, cb)
    cb({})
    StaffMenu.RestoreGestionHub()
end)

-- Saisie texte DANS le hub (évite le clavier NUI coincé sous l'iframe).
function StaffMenu.HubTextInput(title, defaultValue)
    if not hubOpen then
        return VFW.Nui.KeyboardInput(true, title, defaultValue or "")
    end
    hubTextInput = nil
    -- S'assurer que l'iframe est visible (pas couverte)
    SendNUIMessage({ action = "gestion:uncover" })
    SendNUIMessage({
        action = "gestion:textInput",
        data = {
            title = title or "Saisie",
            defaultValue = defaultValue or "",
        },
    })
    VFW.Nui.Focus(true)
    while hubTextInput == nil do
        Wait(50)
    end
    if hubTextInput == false then
        return ""
    end
    return tostring(hubTextInput)
end

RegisterNuiCallback("gestion:textInput:response", function(data, cb)
    cb({})
    if type(data) ~= "table" or data.cancel or data.value == nil then
        hubTextInput = false
    else
        hubTextInput = tostring(data.value)
    end
end)

RegisterNuiCallback("gestion:select", function(data, cb)
    cb({})
    if not hubOpen or type(data) ~= "table" then
        if hubOpen then ResetHubVuiLoading("Sélection NUI invalide") end
        return
    end

    local perms = (VFW.PlayerGlobalData and VFW.PlayerGlobalData.permissions) or {}
    local state = { category = data.category }

    if data.kind == "tool" then
        local idx = tonumber(data.index) or 0
        local catId = data.category
        local lookup = catId and directItemLookup[catId]
        if lookup then
            local item = lookup[idx]
            if not item then
                ResetHubVuiLoading("Outil de gestion introuvable")
                return
            end
            for i = 1, #directCategories do
                if directCategories[i].id == catId and not HasPerm(perms, directCategories[i].perm) then
                    ResetHubVuiLoading("Permission de catégorie refusée")
                    return
                end
            end
            if item.perm and not HasPerm(perms, item.perm) then
                ResetHubVuiLoading("Permission d'outil refusée")
                return
            end
            if item.action then
                RunHubAction(item.action)
                return
            end
            if item.submenu then
                OpenFromHub(StaffMenu[item.submenu], item.onClick, state)
            else
                ResetHubVuiLoading("Aucun gestionnaire pour cet outil")
            end
            return
        end

        local entries = StaffMenu.builderEntries
        local e = entries and entries[idx]
        if not e or not e.label or e.separator then
            ResetHubVuiLoading("Entrée builder introuvable")
            return
        end
        if not perms["builder_menu"]
            or (e.perm and not HasPerm(perms, e.perm) and not (e.altPerm and perms[e.altPerm]))
        then
            ResetHubVuiLoading("Permission builder refusée")
            return
        end

        if e.submenu then
            local submenu = StaffMenu[e.submenu]
            if submenu then
                OpenFromHub(submenu, e.onClick, state)
            else
                ResetHubVuiLoading("Sous-menu builder indisponible : " .. tostring(e.submenu))
            end
        elseif e.openFn then
            OpenFromHub({ open = e.openFn }, e.onClick, state)
        else
            OpenFromHub(nil, e.onClick, state)
        end
    end
end)

RegisterCommand("gestion", function()
    if hubOpen then
        if hubMinimized then
            StaffMenu.RestoreGestionHub()
            return
        end
        StaffMenu.CloseGestionHub()
        return
    end
    StaffMenu.OpenGestionHub()
end, false)

CreateThread(function()
    while true do
        if hubOpen and hubMinimized then
            if IsControlJustPressed(0, 47) then -- G
                StaffMenu.RestoreGestionHub()
            end
            Wait(0)
        else
            Wait(200)
        end
    end
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    if hubOpen then
        hubOpen = false
        hubMinimized = false
        SetVuiHubVisible(false)
        SetNuiFocus(false, false)
    end
end)
