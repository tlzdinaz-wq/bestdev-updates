local crewCount = {}

RegisterNetEvent("vfw:staff:sendGlobalAnnouncement", function(message)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("announce_serv") then return end
    if type(message) ~= "string" or message == "" then return end

    TriggerClientEvent("core:vnotif:createAlert", -1, message:sub(1, 500), "")
end)

RegisterNetEvent("core:vnotif:createAlert:staff", function(message)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("announce_modo") then return end
    if type(message) ~= "string" or message == "" then return end

    for target, other in pairs(VFW.Players) do
        if other.hasPermission("staff_menu") then
            TriggerClientEvent("core:vnotif:createAlert", target, message:sub(1, 500), "")
        end
    end
end)

RegisterNetEvent("vfw:staff:sendZoneAnnouncement", function(radius, message)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("announce_serv") then return end

    radius = tonumber(radius) or 0
    if radius < 1 or radius > 750 then return end
    if type(message) ~= "string" or message == "" then return end

    local nearby = VFW.GetPlayersInRadius(xPlayer.getCoords(), radius)
    for i = 1, #nearby do
        TriggerClientEvent("core:vnotif:createAlert", nearby[i].source, message:sub(1, 500), "")
    end
end)

RegisterNetEvent("core:vnotif:createAlert:zone", function(targetId, message)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("announce_serv") then return end
    if type(message) ~= "string" then return end

    local target = VFW.GetPlayerFromId(tonumber(targetId))
    if not target then return end

    TriggerClientEvent("core:vnotif:createAlert", target.source, message:sub(1, 500), "")
end)

RegisterNetEvent("core:vnotif:createAlert:player", function(msg, targetId, isAnim)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer then return end

    local senderType = isAnim and "animator" or "staff"
    local permission = isAnim and "menu_anim" or "staff_menu"

    if not xPlayer.hasPermission(permission) then
        TriggerClientEvent("vfw:staff:msgResult", source, false, "perm", "", 0, senderType)
        return
    end

    local target = VFW.GetPlayerFromId(tonumber(targetId))
    if not target then
        TriggerClientEvent("vfw:staff:msgResult", source, false, "notfound", "", tonumber(targetId) or 0, senderType)
        return
    end

    TriggerClientEvent("core:vnotif:createAlert", target.source, tostring(msg):sub(1, 500), "")
    TriggerClientEvent("vfw:staff:msgResult", source, true, nil,
        ("%s %s"):format(target.firstName, target.lastName), target.source, senderType)
end)

-- Annonce depuis le menu animateur (Options animateur > Annonces) : le menu envoyait cet événement mais aucun
-- code serveur n'y répondait, rien n'était jamais affiché. Réservé aux animateurs (permission menu_anim) ;
-- annonce globale (tout le serveur) ou limitée à un rayon autour de l'animateur.
local lastAnimatorAnnounce = {}

RegisterNetEvent("vfw:animator:announce", function(message, isGlobal, radius)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("menu_anim") then return end
    if type(message) ~= "string" then return end
    message = message:gsub("[%c]", " "):gsub("^%s+", ""):gsub("%s+$", "")
    if message == "" then return end
    message = message:sub(1, 500)

    local now = GetGameTimer()
    if lastAnimatorAnnounce[source] and now - lastAnimatorAnnounce[source] < 2000 then return end
    lastAnimatorAnnounce[source] = now

    if isGlobal == true then
        TriggerClientEvent("core:vnotif:createAlert", -1, message, "")
        TriggerEvent("vfw:logs:staff", source, "animator_announce", { global = true, message = message })
        return
    end

    radius = tonumber(radius) or 0
    if radius < 1 or radius > 750 then radius = 50 end
    local nearby = VFW.GetPlayersInRadius(xPlayer.getCoords(), radius)
    for i = 1, #nearby do
        TriggerClientEvent("core:vnotif:createAlert", nearby[i].source, message, "")
    end
    TriggerEvent("vfw:logs:staff", source, "animator_announce", { global = false, radius = radius, count = #nearby, message = message })
end)

AddEventHandler("playerDropped", function()
    lastAnimatorAnnounce[source] = nil
end)

RegisterNetEvent("vfw:showPlayerID", function()
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer then return end
    TriggerClientEvent("vfw:receivePlayerID", source, xPlayer.uuid, source)
end)

RegisterServerCallback("vfw:getPlayerUUID", function(source)
    local xPlayer = VFW.GetPlayerFromId(source)
    return xPlayer and xPlayer.uuid or ""
end)

RegisterServerCallback("vfw:getPlayerGlobalData", function(source)
    local xPlayer = VFW.GetPlayerFromId(source)
    if xPlayer then return xPlayer.getGlobalData() end

    local account = VFW.GetPendingAccount(source)
    if not account then return {} end

    local payload = {
        id = account.id,
        uuid = account.uuid,
        permissions = account.permissions or {},
        vip_tier = account.vip_tier or 0,
        level = account.level or 0,
        spacecoins = account.spacecoins or 0,
        role = account.role or "user",
        roleId = account.role_id or 0,
    }
    if VFW.HydrateNiveau6Permissions then
        VFW.HydrateNiveau6Permissions(payload)
    end
    return payload
end)

RegisterNetEvent("vfw:stafflogs:tpm", function(from, to)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("tp") then return end
    if type(from) ~= "table" or type(to) ~= "table" then return end

    TriggerEvent("vfw:logs:staff", source, "tpm", { from = from, to = to })
end)

RegisterNetEvent("vfw:staff:updateVeh", function(props)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("staff_custom") then return end
    if type(props) ~= "table" then return end

    TriggerEvent("vfw:vehicle:updateProperties", source, props)
end)

RegisterNetEvent("core:UpdateCrewCount", function(faction, isJoining)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer then return end
    if type(faction) ~= "string" then return end
    if xPlayer.faction ~= faction then return end

    if faction == "" or faction == "nocrew" then return end

    crewCount[faction] = (crewCount[faction] or 0) + (isJoining and 1 or -1)
    if crewCount[faction] < 0 then crewCount[faction] = 0 end

    GlobalState[("crewCount:%s"):format(faction)] = crewCount[faction]
end)

RegisterNetEvent("vfw:blips:create", function(data)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("manage_blips") then return end
    if type(data) ~= "table" or type(data.positions) ~= "table" then return end

    local blips = VFW.Variables.GetVariable("custom_blips") or {}
    blips[#blips + 1] = data
    VFW.Variables.SetVariable("custom_blips", blips)

    TriggerClientEvent("vfw:blips:create", -1, data)
end)

AddEventHandler("vfw:characterLoaded", function(source)
    local blips = VFW.Variables.GetVariable("custom_blips") or {}
    for i = 1, #blips do
        TriggerClientEvent("vfw:blips:create", source, blips[i])
    end
end)

RegisterNetEvent("core:server:loadedLocation", function()
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer then return end
    TriggerEvent("vfw:player:locationLoaded", source)
end)

local function notifyStaffScreenshot(target, variant, message)
    TriggerClientEvent("vfw:showNotification", target, {
        type = "STAFF",
        variant = variant,
        subtitle = "Screenshot",
        message = message,
        content = message,
    })
end

RegisterNetEvent("vfw:staff:takeScreenshot", function(targetId, playerInfo)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("screenshot") then return end

    targetId = tonumber(targetId)
    if not targetId then return end

    local xTarget = VFW.GetPlayerFromId(targetId)
    if not xTarget then
        notifyStaffScreenshot(source, "ERROR", "Joueur introuvable.")
        return
    end

    if not (VFW.FiveManage and VFW.FiveManage.ApiKey and VFW.FiveManage.ApiKey()) then
        notifyStaffScreenshot(source, "ERROR",
            "FiveManage n'est pas configuré. Renseigne FIVEMANAGE_MEDIA_API_KEY dans server.cfg.")
        return
    end

    local info = {
        name = ("%s %s"):format(xTarget.firstName or "", xTarget.lastName or ""),
        visaId = (type(playerInfo) == "table" and tonumber(playerInfo.visaId)) or 0,
    }

    local answered = false

    local function fail(message)
        if answered then return end
        answered = true
        notifyStaffScreenshot(source, "ERROR", message)
    end

    SetTimeout(20000, function()
        fail("La capture n'a pas abouti dans le délai imparti.")
    end)

    local function screenshotsFolder()
        local folder = GetConvar("core_fivemanage_screenshots_path", "")
        if type(folder) == "string" and folder ~= "" then
            return folder:gsub("^/+", ""):gsub("/+$", "")
        end
        local root = GetConvar("core_fivemanage_path", "")
        if type(root) == "string" and root ~= "" then
            return (root:gsub("^/+", ""):gsub("/+$", "")) .. "/screenshots"
        end
        return "staff/screenshots"
    end

    exports["screenshot-basic"]:requestClientScreenshot(targetId, { encoding = "jpg", quality = 0.7 },
        function(err, data)
            if answered then return end

            if err or type(data) ~= "string" then
                fail("La capture a échoué.")
                return
            end

            CreateThread(function()
                if answered then return end

                local dataUrl = data
                if not dataUrl:match("^data:") then
                    dataUrl = "data:image/jpeg;base64," .. data
                end
                local filename = ("%s_%s.jpg"):format(targetId, os.time())
                local url = VFW.FiveManage.UploadBase64(dataUrl, filename, screenshotsFolder())

                if answered then return end
                if type(url) ~= "string" or url == "" then
                    fail("L'envoi FiveManage a échoué (voir la console serveur).")
                    return
                end

                answered = true
                TriggerClientEvent("vfw:staff:receiveScreen", source, url, info)
            end)
        end)
end)

local staffMode = {}

-- Declare ici, et non pres du mode animateur plus bas : les compteurs du bandeau
-- staff le lisent, et une locale declaree apres eux leur serait invisible.
local animatorMode = {}

local function currentStaffModeList()
    local list, n = {}, 0
    for src in pairs(staffMode) do
        n = n + 1
        list[n] = src
    end
    return list
end

--- Les compteurs du bandeau staff : combien de staff connectes, combien en service.
---
--- Le client ecoutait `vfw:staff:sendStaffsData` depuis toujours, mais personne ne
--- l'emettait. Les deux compteurs restaient a zero, et l'affichage force 1 quand la
--- valeur est nulle : le bandeau indiquait donc « 1 en ligne, 1 en service » quel que
--- soit le nombre reel de staff.
local function broadcastStaffCounts()
    local online, inService = 0, 0

    for _, xPlayer in pairs(VFW.GetExtendedPlayers()) do
        if xPlayer.hasPermission("staff_menu") or xPlayer.hasPermission("menu_anim") then
            online = online + 1
            if staffMode[xPlayer.source] or animatorMode[xPlayer.source] then
                inService = inService + 1
            end
        end
    end

    -- A tout le monde : seul le staff affiche ce bandeau, et le client sait deja
    -- s'il doit le montrer.
    TriggerClientEvent("vfw:staff:sendStaffsData", -1, {
        onlineStaffs = online,
        staffsInService = inService,
    })
end

local function broadcastStaffMode()
    TriggerClientEvent("vfw:staff:syncStaffMode", -1, currentStaffModeList())
    broadcastStaffCounts()
end

local function staffNotify(source, variant, subtitle, message)
    TriggerClientEvent("vfw:showNotification", source, {
        type = "STAFF",
        variant = variant,
        subtitle = subtitle,
        message = message,
    })
end

local function staffRadius(value, maximum)
    local radius = tonumber(value)
    if not radius or radius <= 0 then return nil end
    if radius > maximum then return maximum end
    return radius
end

local function staffVehicleByPlate(plate)
    if type(plate) ~= "string" then return nil end
    if not VFW.Vehicles or not VFW.Vehicles.FindEntityByPlate then return nil end

    local vehicle = VFW.Vehicles.FindEntityByPlate(plate)
    if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) then return nil end
    return vehicle
end

local function staffNormalizedPlate(plate)
    if not VFW.Vehicles or not VFW.Vehicles.NormalizePlate then return "" end
    return VFW.Vehicles.NormalizePlate(plate) or ""
end

RegisterNetEvent("vfw:staff:mode", function(enabled, bypassOutfit)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("staff_menu") then return end

    local active = enabled and true or false
    staffMode[source] = active or nil

    broadcastStaffMode()
    TriggerClientEvent("vfw:staff:modeChanged", source, active)

    if active then
        -- Tenue staff temporairement désactivée (ne plus forcer le costume).
    else
        TriggerClientEvent("vfw:staff:setStaffClothes", source, false)
        TriggerClientEvent("staff:onStaffModeExit", source)
    end

    TriggerEvent("vfw:logs:staff", source, "staff_mode", { enabled = active })
end)

AddEventHandler("playerDropped", function()
    local source = source

    -- Un staff qui part fait baisser le nombre en ligne, meme s'il n'etait pas en
    -- service. Le compte se fait apres coup : il figure encore dans la liste des
    -- joueurs a cet instant.
    SetTimeout(0, broadcastStaffCounts)

    if not staffMode[source] then return end

    staffMode[source] = nil
    broadcastStaffMode()
end)

RegisterNetEvent("vfw:staff:clearZone", function(radius)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("clean_zone") then return end

    local range = staffRadius(radius, 500)
    if not range then return end

    local coords = xPlayer.getCoords()
    if not coords then return end

    local zone = { x = coords.x, y = coords.y, z = coords.z }
    local nearby = VFW.GetPlayersInRadius(coords, range + 100)
    for i = 1, #nearby do
        TriggerClientEvent("vfw:clearZone", nearby[i].source, zone, range)
    end

    staffNotify(source, "SUCCESS", "Outils Staff",
        ("Nettoyage lancé dans un rayon de %d mètres."):format(math.floor(range)))
    TriggerEvent("vfw:logs:staff", source, "clear_zone", { radius = range, coords = zone })
end)

RegisterNetEvent("vfw:staff:reviveZone", function(radius)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("zone_actions") then return end

    local range = staffRadius(radius, 500)
    if not range then return end

    local nearby = VFW.GetPlayersInRadius(xPlayer.getCoords(), range)
    local revived = 0
    for i = 1, #nearby do
        if nearby[i].dead then
            nearby[i].revive()
            revived = revived + 1
        end
    end

    local message
    if revived == 0 then
        message = "Aucun joueur au sol dans ce rayon."
    elseif revived == 1 then
        message = "1 joueur réanimé."
    else
        message = ("%d joueurs réanimés."):format(revived)
    end

    staffNotify(source, revived > 0 and "SUCCESS" or "INFO", "Outils Staff", message)
    TriggerEvent("vfw:logs:staff", source, "revive_zone", { radius = range, count = revived })
end)

RegisterNetEvent("vfw:staff:selfFillNeeds", function(need)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer then return end
    if not xPlayer.hasPermission("heal") and not xPlayer.hasPermission("menu_anim") then return end

    if need == "hunger" then
        VFW.SetStatus(source, 100, nil)
    elseif need == "thirst" then
        VFW.SetStatus(source, nil, 100)
    elseif need == "both" then
        VFW.SetStatus(source, 100, 100)
    end
end)

RegisterNetEvent("vfw:staff:spawnVehicle", function(model, posX, posY, posZ, heading)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("alt_spawn_vehicle") then return end
    if type(model) ~= "string" or model == "" or #model > 32 then return end

    local x, y, z = tonumber(posX), tonumber(posY), tonumber(posZ)
    if not x or not y or not z then return end
    if not Feat27 or not Feat27.SpawnVehicle then return end

    local hash = joaat(model)
    local vehicleType = VFW.GetVehicleType and VFW.GetVehicleType(hash, source) or "automobile"
    local netId, spawned = Feat27.SpawnVehicle(hash, { x = x, y = y, z = z }, tonumber(heading) or 0.0, vehicleType)

    if not netId then
        staffNotify(source, "ERROR", "Spawn véhicule", "Ce véhicule n'a pas pu apparaître.")
        return
    end
    -- déverrouillé et exempté de l'anti-vol (voir plugins/015_Features/server/vehicle_lock.lua)
    if VFW.MarkStaffVehicle then VFW.MarkStaffVehicle(spawned or NetworkGetEntityFromNetworkId(netId)) end

    staffNotify(source, "SUCCESS", "Spawn véhicule", "Le véhicule est apparu.")
    TriggerEvent("vfw:logs:staff", source, "spawn_vehicle", { model = model, coords = { x = x, y = y, z = z } })
end)

RegisterNetEvent("vfw:staff:bringVehicle", function(plate)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("bring_vehicle") then return end

    local vehicle = staffVehicleByPlate(plate)
    if not vehicle then
        staffNotify(source, "ERROR", "Véhicule", "Aucun véhicule sorti ne porte cette plaque.")
        return
    end

    local coords = xPlayer.getCoords(true)
    local heading = tonumber(coords.heading) or 0.0
    local radians = math.rad(heading)

    SetEntityCoords(vehicle,
        coords.x - math.sin(radians) * 3.5,
        coords.y + math.cos(radians) * 3.5,
        coords.z, false, false, false, false)
    SetEntityHeading(vehicle, heading)

    staffNotify(source, "SUCCESS", "Véhicule", "Le véhicule a été amené devant vous.")
    TriggerEvent("vfw:logs:staff", source, "bring_vehicle", { plate = staffNormalizedPlate(plate) })
end)

local function staffGoToVehicle(source, plate)
    local vehicle = staffVehicleByPlate(plate)
    if not vehicle then
        staffNotify(source, "ERROR", "Véhicule", "Aucun véhicule sorti ne porte cette plaque.")
        return
    end

    local coords = GetEntityCoords(vehicle)
    TriggerClientEvent("vfw:teleportTo", source, coords.x + 2.5, coords.y, coords.z)
    TriggerEvent("vfw:logs:staff", source, "goto_vehicle", { plate = staffNormalizedPlate(plate) })
end

RegisterNetEvent("vfw:staff:gotoVehicle", function(plate)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("goto_vehicle") then return end

    staffGoToVehicle(source, plate)
end)

RegisterNetEvent("vfw:staff:tpToVehicle", function(plate)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer then return end
    if not xPlayer.hasPermission("staff_vehicle_tp") and not xPlayer.hasPermission("alt_teleport") then return end

    staffGoToVehicle(source, plate)
end)

local function staffChatBroadcast(source, message)
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("staff_chat") then return end
    if type(message) ~= "string" then return end

    local text = message:sub(1, 300)
    if text:gsub("%s", "") == "" then return end

    local globalData = xPlayer.getGlobalData()
    local rank = globalData and globalData.role
    if type(rank) ~= "string" or rank == "" then rank = "Staff" end

    for target, other in pairs(VFW.Players) do
        if other.hasPermission("staff_chat") then
            TriggerClientEvent("vfw:staff:receiveStaffMessage", target, xPlayer.name, text, rank, "cyan")
        end
    end

    TriggerEvent("vfw:logs:staff", source, "staff_chat", { message = text })
end

RegisterNetEvent("vfw:staff:sendStaffMessage", function(message)
    local source = source
    staffChatBroadcast(source, message)
end)

--- Message de service visible uniquement du staff (sanctions, actions de modération).
--- Utilisé par les sanctions pour que tout le staff connecté voie qui a sanctionné qui.
---@param message string
---@param tone string|nil couleur : red, orange, yellow, green, cyan, purple
function VFW.StaffBroadcast(message, tone)
    if type(message) ~= "string" or message == "" then return end

    for target, other in pairs(VFW.Players) do
        if other.hasPermission("staff_chat") or other.hasPermission("staff_menu") then
            TriggerClientEvent("vfw:staff:receiveStaffMessage", target,
                "Modération", message:sub(1, 400), "Staff", tone or "orange")
        end
    end
end

-- Le chat staff n'était accessible que par /sc (commande client) et par le menu : on
-- l'enregistre aussi côté serveur pour qu'il passe par le pont du chat, apparaisse dans
-- les suggestions et respecte la même vérification de permission que le reste.
VFW.RegisterCommand("mstaff", "staff_chat", function(source, _xPlayer, args)
    local message = table.concat(args or {}, " ")
    if message:gsub("%s", "") == "" then return end
    staffChatBroadcast(source, message)
end, {
    help = "Parler dans le chat staff",
    params = { { name = "message", help = "Message visible uniquement par le staff" } },
})

RegisterNetEvent("vfw:staff:sendChatMessage", function(message)
    local source = source
    staffChatBroadcast(source, message)
end)

local function canHubEnvironment(xPlayer, perm)
    if not xPlayer then return false end
    return xPlayer.hasPermission(perm) or xPlayer.hasPermission("server_management") or xPlayer.hasPermission("admin")
end

RegisterNetEvent("vfw:staff:setTime", function(hour, minute)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not canHubEnvironment(xPlayer, "time") then return end

    local newHour = tonumber(hour)
    if not newHour then return end
    local newMinute = tonumber(minute) or 0

    TriggerEvent("vfw:environment:setTime", newHour, newMinute)
    TriggerEvent("vfw:logs:staff", source, "set_time", { hour = newHour, minute = newMinute })
end)

RegisterNetEvent("vfw:staff:setWeather", function(weather)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not canHubEnvironment(xPlayer, "weather") then return end
    if type(weather) ~= "string" or weather == "" or #weather > 32 then return end

    TriggerEvent("vfw:environment:setWeather", weather)
    TriggerEvent("vfw:logs:staff", source, "set_weather", { weather = weather:upper() })
end)

RegisterNetEvent("vfw:staff:freezeTime", function(frozen)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not canHubEnvironment(xPlayer, "freezetime") then return end

    local state = frozen and true or false
    TriggerEvent("vfw:environment:freezeTime", state)
    TriggerEvent("vfw:logs:staff", source, "freeze_time", { frozen = state })
end)

RegisterNetEvent("vfw:staff:freezeWeather", function(frozen)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not canHubEnvironment(xPlayer, "freezeweather") then return end

    local state = frozen and true or false
    TriggerEvent("vfw:environment:freezeWeather", state)
    TriggerEvent("vfw:logs:staff", source, "freeze_weather", { frozen = state })
end)

local function currentAnimatorModeList()
    local list, n = {}, 0
    for src in pairs(animatorMode) do
        n = n + 1
        list[n] = src
    end
    return list
end

local function broadcastAnimatorMode()
    TriggerClientEvent("vfw:animator:syncAnimatorMode", -1, currentAnimatorModeList())
    broadcastStaffCounts()
end

RegisterNetEvent("vfw:animator:mode", function(enabled)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("menu_anim") then return end

    local active = enabled and true or false
    animatorMode[source] = active or nil

    broadcastAnimatorMode()
    TriggerEvent("vfw:logs:staff", source, "animator_mode", { enabled = active })
end)

AddEventHandler("playerDropped", function()
    local source = source
    if not animatorMode[source] then return end

    animatorMode[source] = nil
    broadcastAnimatorMode()
end)

local hiddenGamerTags = {}

local function canUseGamerTags(xPlayer)
    return xPlayer
        and (xPlayer.hasPermission("staff_menu")
            or xPlayer.hasPermission("show_gamertag")
            or xPlayer.hasPermission("menu_anim"))
end

local function gamerTagPlaytime(target)
    local playtime = 0
    if target.globalData then
        playtime = tonumber(target.globalData.playtime) or 0
    end
    if target.sessionStart then
        playtime = playtime + math.max(0, os.time() - target.sessionStart)
    end
    return playtime
end

local function gamerTagCrew(target)
    if target.job2 then
        return target.job2.label or target.job2.name or "NoCrew"
    end
    if type(target.faction) == "table" then
        return target.faction.label or target.faction.name or "NoCrew"
    end
    if type(target.faction) == "string" and target.faction ~= "" then
        return target.faction
    end
    return "NoCrew"
end

local function gamerTagRankColor(target)
    local roleId = target.globalData and target.globalData.role
    if type(roleId) ~= "string" or roleId == "" or roleId == "user" then
        return nil
    end
    if not Staff299 or not Staff299.Roles or type(Staff299.Roles.Load) ~= "function" then
        return nil
    end

    local ok, roles = pcall(Staff299.Roles.Load)
    if not ok or type(roles) ~= "table" then return nil end

    local role = roles[roleId]
    if type(role) ~= "table" or type(role.color) ~= "string" then return nil end
    if not role.color:match("^#?%x%x%x%x%x%x$") then return nil end
    return role.color
end

local function gamerTagPayload(target)
    if not target then return nil end

    local source = tonumber(target.source)
    local playerName = target.playerName or (source and GetPlayerName(source)) or "unknown"
    local rpName = target.name
    if (not rpName or rpName == "") and target.firstName and target.lastName then
        rpName = ("%s %s"):format(target.firstName, target.lastName)
    end

    local vipTier = tonumber(target.vipTier or (target.globalData and target.globalData.vip_tier)) or 0

    return {
        ID = target.uuid or target.charId or source,
        UUID = target.uuid or target.charId or source,
        SOURCE_ID = source,
        NAME = playerName,
        RP_NAME = rpName or playerName,
        CREW = gamerTagCrew(target),
        NEW = gamerTagPlaytime(target) <= 3600,
        NEW_REMAINING = math.max(0, 3601 - gamerTagPlaytime(target)),
        PREMIUM = vipTier > 0,
        COLOR = gamerTagRankColor(target),
        STAFF_DUTY = staffMode[source] == true,
        ANIMATOR_DUTY = animatorMode[source] == true,
        IS_GAMERTAG = true,
    }
end

local function pushGamerTag(targetSource)
    targetSource = tonumber(targetSource)
    if not targetSource or hiddenGamerTags[targetSource] then return end

    local target = VFW.GetPlayerFromId(targetSource)
    if not target then return end

    local payload = gamerTagPayload(target)
    if not payload then return end

    for _, viewer in pairs(VFW.GetExtendedPlayers()) do
        if canUseGamerTags(viewer) then
            TriggerClientEvent("Admin:updateValue", viewer.source, targetSource, payload)
        end
    end
end

AddEventHandler("vfw:gamerTag:refresh", function(targetSource)
    pushGamerTag(targetSource)
end)

AddEventHandler("vfw:gamerTag:refreshAll", function()
    local players = VFW.GetPlayers and VFW.GetPlayers() or {}
    for i = 1, #players do
        pushGamerTag(players[i])
    end
end)

-- Un ID serveur peut être réutilisé : envoyer les nouvelles données aux staff
-- réinitialise aussi le cache client qui masquait l'ancien joueur déconnecté.
AddEventHandler("vfw:characterLoaded", function(source, xPlayer)
    broadcastStaffCounts()

    local target = xPlayer or VFW.GetPlayerFromId(source)
    if not target or hiddenGamerTags[source] then return end
    local payload = gamerTagPayload(target)
    for _, viewer in pairs(VFW.GetExtendedPlayers()) do
        if canUseGamerTags(viewer) then
            TriggerClientEvent("Admin:updateValue", viewer.source, source, payload)
        end
    end
end)

RegisterNetEvent("Admin:gamerTag", function(enabled)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not canUseGamerTags(xPlayer) then return end

    TriggerClientEvent("Admin:gamerTag", source, enabled and true or false)
end)

RegisterNetEvent("Admin:requestPlayerData", function(targetServerId)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not canUseGamerTags(xPlayer) then return end

    local target = tonumber(targetServerId)
    if not target then return end

    if hiddenGamerTags[target] and target ~= source then
        TriggerClientEvent("Admin:removeValue", source, target)
        return
    end

    local xTarget = VFW.GetPlayerFromId(target)
    if not xTarget then
        TriggerClientEvent("Admin:removeValue", source, target)
        return
    end

    local payload = gamerTagPayload(xTarget)
    if payload then
        TriggerClientEvent("Admin:updateValue", source, target, payload)
    end
end)

RegisterNetEvent("Admin:hideMyTag", function(hidden)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("hide_gamertag") then return end

    local hide = hidden and true or false
    hiddenGamerTags[source] = hide or nil

    if hide then
        TriggerClientEvent("Admin:removeValue", -1, source)
        return
    end

    local payload = gamerTagPayload(xPlayer)
    if payload then
        TriggerClientEvent("Admin:updateValue", -1, source, payload)
    end
end)

AddEventHandler("playerDropped", function()
    local source = source
    hiddenGamerTags[source] = nil
    TriggerClientEvent("Admin:removeValue", -1, source)
end)

-- ══════════════════════════════════════════════════════════════════════════
-- Blips staff : position des joueurs sur la carte.
--
-- `Admin:activeBlips` était déclenché par le menu et la touche staff, mais aucun
-- handler serveur n'existait : aucun blip n'apparaissait jamais. On tient ici la
-- liste des admins qui les ont activés et on leur envoie les positions.
-- ══════════════════════════════════════════════════════════════════════════

local blipWatchers = {}
local BLIP_REFRESH_MS = 2500

local function blipJobLabel(target)
    local job = target.job
    if type(job) == "table" and (job.label or job.name) then
        return job.label or job.name
    end
    return nil
end

local function blipPayload()
    local players = {}
    local xPlayers = VFW.GetPlayers and VFW.GetPlayers() or {}

    for i = 1, #xPlayers do
        local target = VFW.GetPlayerFromId(xPlayers[i])
        if target and target.source then
            local coords = target.getCoords()
            if coords then
                players[#players + 1] = {
                    id = target.source,
                    name = target.name or GetPlayerName(target.source) or ("#" .. target.source),
                    job = blipJobLabel(target),
                    staff = staffMode[target.source] == true,
                    x = coords.x + 0.0,
                    y = coords.y + 0.0,
                    z = coords.z + 0.0,
                }
            end
        end
    end

    return players
end

RegisterNetEvent("Admin:activeBlips", function(enabled)
    local source = source
    local xPlayer = VFW.GetPlayerFromId(source)
    if not canUseGamerTags(xPlayer) then return end

    if enabled ~= true then
        blipWatchers[source] = nil
        TriggerClientEvent("Admin:blips", source, false, {})
        return
    end

    blipWatchers[source] = true
    TriggerClientEvent("Admin:blips", source, true, blipPayload())
end)

CreateThread(function()
    while true do
        Wait(BLIP_REFRESH_MS)

        if next(blipWatchers) then
            local payload = blipPayload()
            for watcher in pairs(blipWatchers) do
                if VFW.GetPlayerFromId(watcher) then
                    TriggerClientEvent("Admin:blips", watcher, true, payload)
                else
                    blipWatchers[watcher] = nil
                end
            end
        end
    end
end)

AddEventHandler("playerDropped", function()
    blipWatchers[source] = nil
end)

RegisterServerCallback("vfw:staff:getJobs", function(source)
    local xPlayer = VFW.GetPlayerFromId(source)
    if not xPlayer or not xPlayer.hasPermission("staff_menu") then return {} end

    return VFW.Jobs or {}
end)
