---@type fun(nuiAction: string, serverEvent: string) NUI->server pass-through registrar (client.nui).
local proxyCallback = require 'client.nui'

proxyCallback('sd-phone:health:summary',     'sd-phone:server:health:summary')
proxyCallback('sd-phone:health:leaderboard', 'sd-phone:server:health:leaderboard')

---Resolves the player's current activity state; the most-intense match wins.
---@param ped number
---@return 'dead'|'vehicle'|'sprinting'|'running'|'walking'|'idle'
local function detectState(ped)
    if IsEntityDead(ped) or IsPedDeadOrDying(ped, true) then return 'dead' end
    if cache.vehicle then return 'vehicle' end
    if IsPedSprinting(ped) then return 'sprinting' end
    if IsPedRunning(ped)   then return 'running' end
    if IsPedWalking(ped)   then return 'walking' end
    return 'idle'
end

---@type table<string, number> Steps per second by activity state.
local CADENCE = {
    idle      = 0,
    walking   = 1.83,
    running   = 2.83,
    sprinting = 3.33,
    vehicle   = 0,
    dead      = 0,
}

---@type table<string, integer> Heart-rate target (bpm) the smoother pulls toward, by activity state.
local TARGET_HR = {
    idle      = 70,
    walking   = 90,
    running   = 125,
    sprinting = 160,
    vehicle   = 75,
    dead      = 0,
}

-- Asymmetric low-pass on heart rate: rises quickly, recovers slowly, with per-tick jitter.
---@type number Smoothing alpha per nominal tick while the rate is rising.
local HR_ALPHA_RISE = 0.05
---@type number Smoothing alpha per nominal tick while the rate is recovering.
local HR_ALPHA_FALL = 0.02
---@type number Maximum +/- bpm of per-tick jitter.
local HR_JITTER     = 1.5

---@type number Single-tick position deltas (metres) above this are treated as teleports and skipped.
local MAX_TICK_DISTANCE_M = 50.0

---@type integer Sampler cadence in ms.
local TICK_MS = 250

---@type boolean Whether Health is switched on in configs/apps.lua. Off means no sampler at all:
---this is the one app that costs every player's game thread whether or not they open it.
local APP_ENABLED = require('client.appids').enabled('health')

---@type table Session running totals: steps, distanceM (on-foot metres), heartRate (bpm), activity state.
local stats = {
    steps     = 0,
    distanceM = 0,
    heartRate = 70,
    state     = 'idle',
}

---@type table Banked-since-last-flush amounts. The server takes deltas rather than totals so a
---relog cannot re-bank a whole session, and it caps each one against the time it had to happen in.
local pending = {
    steps     = 0,
    distanceM = 0,
    activeMs  = 0,
    peakHr    = 0,
}

---@type integer Seconds between flushes while the player is connected.
local FLUSH_SECONDS <const> = 60

---Hands the accumulated deltas to the server and starts a fresh window. An empty flush is dropped
---rather than sent.
local function flush()
    if pending.steps < 1 and pending.distanceM < 1 and pending.activeMs < 1 and pending.peakHr < 1 then
        return
    end

    TriggerServerEvent('sd-phone:server:health:flush', {
        steps     = math.floor(pending.steps),
        distanceM = math.floor(pending.distanceM),
        activeMs  = math.floor(pending.activeMs),
        heartRate = math.floor(pending.peakHr),
    })

    pending.steps, pending.distanceM, pending.activeMs, pending.peakHr = 0, 0, 0, 0
end

---Per-tick sampler: classifies the ped, accumulates steps + on-foot distance, and smooths heart
---rate toward the per-state target. Runs for the lifetime of the resource.
CreateThread(function()
    if not APP_ENABLED then return end

    local lastPos
    local lastTickMs = GetGameTimer()

    while true do
        Wait(TICK_MS)
        local ped = cache.ped
        if DoesEntityExist(ped) then
            local now = GetGameTimer()
            local dt  = (now - lastTickMs) / 1000.0
            lastTickMs = now

            local state = detectState(ped)
            stats.state = state

            local tickSteps = CADENCE[state] * dt
            stats.steps   = stats.steps + tickSteps
            pending.steps = pending.steps + tickSteps

            local onFoot = state == 'walking' or state == 'running' or state == 'sprinting'
            if onFoot then pending.activeMs = pending.activeMs + (dt * 1000.0) end

            local pos = GetEntityCoords(ped)
            if lastPos and onFoot then
                local delta = #(pos - lastPos)
                if delta < MAX_TICK_DISTANCE_M then
                    stats.distanceM   = stats.distanceM + delta
                    pending.distanceM = pending.distanceM + delta
                end
            end
            lastPos = pos

            if state ~= 'dead' then
                local target    = TARGET_HR[state]
                local baseA     = (target > stats.heartRate) and HR_ALPHA_RISE or HR_ALPHA_FALL
                local effective = math.min(1.0, baseA * (dt / (TICK_MS / 1000.0)))
                stats.heartRate = stats.heartRate + (target - stats.heartRate) * effective
                stats.heartRate = stats.heartRate + (math.random() - 0.5) * HR_JITTER * 2
                if stats.heartRate > pending.peakHr then pending.peakHr = stats.heartRate end
            else
                stats.heartRate = 0
            end
        end
    end
end)

---@type boolean True while the phone is on screen (gates the NUI pump below).
local phoneOpen = false

---Pushes the current stats snapshot into the NUI; steps floor, heart rate rounds. Carries the
---unflushed amounts too, which the app adds to the server's daily total.
local function pushSnapshot()
    SendNUIMessage({
        action = 'sd-phone:health',
        data = {
            steps     = math.floor(stats.steps),
            distanceM = stats.distanceM,
            heartRate = lib.math.round(stats.heartRate),
            state     = stats.state,
            pending   = {
                steps     = math.floor(pending.steps),
                distanceM = math.floor(pending.distanceM),
                activeMs  = math.floor(pending.activeMs),
            },
        },
    })
end

---Phone open/close signal from the phone shell; pushes one snapshot immediately on open.
---@param open boolean whether the phone is now on screen
AddEventHandler('sd-phone:client:openState', function(open)
    phoneOpen = open
    if open then pushSnapshot() end
end)

-- 1s NUI pump while the phone is on screen.
CreateThread(function()
    if not APP_ENABLED then return end

    while true do
        Wait(1000)
        if phoneOpen then pushSnapshot() end
    end
end)

-- 60s flush pump. Runs whether or not the phone is on screen.
CreateThread(function()
    if not APP_ENABLED then return end

    while true do
        Wait(FLUSH_SECONDS * 1000)
        flush()
    end
end)

-- Final flush on resource stop.
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if APP_ENABLED then flush() end
end)
