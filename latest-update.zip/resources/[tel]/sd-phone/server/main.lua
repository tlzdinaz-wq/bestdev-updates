-- Build-presence guard: a source checkout without a compiled NUI (web/build is
-- gitignored and shipped via GitHub Releases) would open to a blank phone.
if not LoadResourceFile(GetCurrentResourceName(), 'web/build/index.html') then
    print('^1[sd-phone] NUI build not found at web/build/index.html.^0')
    print('^3[sd-phone] Download the packaged release from GitHub Releases, or build it: cd web && npm ci && npm run build^0')
end

---@type table sd-phone config root (configs/config.lua).
local config    = require 'configs.config'
---@type table Inventory bridge (bridge.server.inventory): backend-agnostic item ops.
local inv       = require 'bridge.server.inventory'
---@type table Shared server helpers (server.util): the failure envelope a crashed handler answers with.
local util      = require 'server.util'

-- Every callback handler the app modules register below runs under pcall. A handler that throws
-- (a schema mismatch, a nil field) would otherwise never resolve, and the phone would spin on
-- the promise until ox_lib's timeout instead of showing an error.
do
    local register = lib.callback.register
    lib.callback.register = function(name, handler)
        return register(name, function(...)
            local results = table.pack(pcall(handler, ...))
            if results[1] then return table.unpack(results, 2, results.n) end
            print(('^1[sd-phone] callback %s failed: %s^0'):format(tostring(name), tostring(results[2])))
            return util.fail('common.serverError', 'Something went wrong')
        end)
    end
end

-- Loaded for side effects: each module self-registers its callbacks, events, commands and exports on require.
-- SIM first: when unique phones are enabled it wraps player.getIdentifier before any app module
-- captures a callback against it (they all resolve identity at call time, but keep it first for
-- clarity - the wrapper must also be live before the boot-time registrations below).
require 'server.sim.init'
-- ESX only, and only without a dedicated inventory resource: puts the phone items in the `items`
-- table so ESX will honour them. Reads config.Sim, so it sits after the SIM module.
require 'server.esxitems'
-- VFW only (inert elsewhere): phone numbers shared with core's character_phones directory.
require 'server.vfw'
require 'server.settings.init'
require 'server.service'
require 'server.wifi'
require 'server.bluetooth.init'
require 'server.apps.init'
require 'server.groups.init'
require 'server.mail.init'
require 'server.messages.init'
require 'server.photos.init'
require 'server.birdy.init'
require 'server.accounts.init'
require 'server.contacts.init'
require 'server.calls.init'
require 'server.payphone.init'
require 'server.badges.init'
require 'server.gifs.init'
require 'server.garages.init'
require 'server.garages.valet'
require 'server.darkchat.init'
require 'server.marketplace.init'
require 'server.pages.init'
require 'server.weazelnews.init'
require 'server.banking.init'
require 'server.services.init'
-- VFW only (inert elsewhere): the Services directory follows the societies made in Gestion.
require 'server.vfwcompanies'
require 'server.voicememos.init'
require 'server.callrec.init'
require 'server.voicemail.init'
require 'server.music.init'
require 'server.share.init'
require 'server.devseed.init'
-- Optional local-only helpers; absent on every install but a developer's, so a missing file is
-- expected rather than an error.
pcall(require, 'server.devswap')
require 'server.notifications.init'
require 'server.notes.init'
require 'server.search.init'
require 'server.calendar.init'
require 'server.documents.init'
require 'server.homes.init'
require 'server.maps.init'
require 'server.friends.init'
require 'server.cherry.init'
-- Ahead of the three features that stream live video, so the relay's gate is resolved and its
-- feature registry is there to be registered against before any of them takes a viewer.
require 'server.media.init'
require 'server.photogram.init'
require 'server.webhooks.init'
require 'server.vibez.init'
require 'server.voice.init'
require 'server.streaks.init'
require 'server.id.init'
require 'server.mdt.init'
require 'server.racing.init'
require 'server.health.init'
require 'server.medical.init'
require 'server.gates'
require 'server.appgate'
require 'server.ryde.init'
require 'server.radio.init'
require 'server.clock.init'
require 'server.cookie.init'
require 'server.stocks.init'
require 'server.chess.init'
require 'server.connectfour.init'
require 'server.games.chips'
require 'server.games.blackjack'
require 'server.games.casino.roulette'
require 'server.games.casino.slots'
require 'server.games.casino.baccarat'
require 'server.games.casino.crash.init'
require 'server.games.casino.holdem.init'
require 'server.battleship.init'
require 'server.wordle.init'
require 'server.admin.wipe'
require 'server.admin.init'
-- lb-phone -> sd-phone one-time data import (no-op unless lb-phone's tables are present).
require 'server.migrate.init'
-- Loaded for side effects: publishes the phone's live per-player state onto player state bags.
require 'server.statebags'

-- lb-phone export compatibility shim (inert while the real lb-phone runs; sd_phone_lbcompat kill switch).
require 'server.compat.lbphone.init'
-- lb-tablet dispatch export compatibility shim (inert while the real lb-tablet runs; sd_phone_lbtabletcompat kill switch).
require 'server.compat.lbtablet.init'
-- yseries export compatibility shim (inert while the real yseries runs; sd_phone_yseriescompat kill switch).
require 'server.compat.yseries.init'
-- qs-smartphone export compatibility shim (sd_phone_qscompat kill switch).
require 'server.compat.qssmartphone.init'
-- gksphone export compatibility shim (sd_phone_gkscompat kill switch).
require 'server.compat.gksphone.init'
-- roadphone export compatibility shim (sd_phone_roadphonecompat kill switch).
require 'server.compat.roadphone.init'
-- qb-phone event and export compatibility shim (sd_phone_qbphonecompat kill switch).
require 'server.compat.qbphone.init'

---@type table SIM feature flags (server.sim.state): active + mode.
local simState = require 'server.sim.state'

---Registers each configured phone item (config.Phone.Items) as a usable item; using one opens
---the phone with the variant's frame colour (plus the SIM snapshot under unique phones). The
---used slot marks that exact phone as the active one, so a player carrying several SIM'd
---phones acts (and calls) as whichever phone they actually opened.
local function RegisterPhoneItems()
    for _, entry in ipairs(config.Phone.Items or {}) do
        inv.registerUsable(entry.item, function(source, itemArg, invArg, slotArg)
            local deviceHint
            if simState.active then
                local usedSlot = (type(itemArg) == 'table' and tonumber(itemArg.slot)) or tonumber(slotArg)
                    or (type(invArg) == 'table' and tonumber(invArg.slot)) or nil
                require('server.sim.session').setActive(source, { slot = usedSlot, color = entry.color })
                -- Synchronous metadata peek (no DB): hands the client this phone's device
                -- identity with the open, so switching phones tears the old profile down AT the
                -- reveal instead of a server round-trip later.
                if usedSlot then
                    local row = inv.getSlot(source, usedSlot)
                    local md = row and row.metadata
                    deviceHint = type(md) == 'table' and md.deviceId or nil
                end
            end
            -- Open immediately: the SIM resolve does inventory scans + awaited DB writes, so it
            -- runs AFTER the reveal and reconciles through the live simState push.
            TriggerClientEvent('sd-phone:client:openFromItem', source, entry.color, nil, simState.active, deviceHint)
            if simState.active then
                CreateThread(function() require('server.sim.session').push(source) end)
            end
        end)
    end
end

---Server-authoritative ownership gate for the keybind: returns the frame colour to open with,
---preferring the client's last-used hint among owned variants, else the first owned variant.
---@param source integer player server id
---@param preferred string|nil last-used frame colour hint
---@return string|nil color frame colour to open with, nil when no phone item is owned
local function ResolveOwnedColor(source, preferred)
    local items = config.Phone.Items or {}
    if preferred then
        for _, entry in ipairs(items) do
            if entry.color == preferred and inv.count(source, entry.item) > 0 then
                return entry.color
            end
        end
    end
    for _, entry in ipairs(items) do
        if inv.count(source, entry.item) > 0 then
            return entry.color
        end
    end
    return nil
end

---Keybind open request: may this player open a phone, and in which colour? Returns the bare
---colour string normally; under unique phones { color, pending = true } and the deferred
---simState push corrects hasSim/number - and the colour, since the SIM'd phone's wins.
lib.callback.register('sd-phone:server:phone:resolveOpen', function(source, preferred)
    local color = ResolveOwnedColor(source, preferred)
    if not simState.active then return color end
    if not color then return nil end
    if type(preferred) == 'string' then
        require('server.sim.session').setActive(source, { color = preferred })
    end
    -- Same deferral as the item path: answer with the colour now, resolve the SIM after.
    CreateThread(function() require('server.sim.session').push(source) end)
    return { color = color, pending = true }
end)

-- Boot: registers the usable phone items once, then prints the startup banner.
CreateThread(function()
    Wait(50)
    RegisterPhoneItems()

end)

---Public export: does this player own a phone - exports['sd-phone']:hasPhone(source). Returns
---the frame colour of the first owned phone item, or nil when the player owns none.
---@param source number player server id
---@return string|nil color owned frame colour, nil when no phone item is owned
exports('hasPhone', function(source)
    if type(source) ~= 'number' then return nil end
    if not GetPlayerName(source) then return nil end
    return ResolveOwnedColor(source, nil)
end)

require 'server.compat.lbphone.clientsupport'
