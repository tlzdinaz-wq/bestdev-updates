---@type table sd-phone config root (configs/config.lua): aggregated per-app config tables.
local config      = require 'configs.config'
---@type table Player bridge (bridge.server.player): citizenid/name lookups from a live source,
---plus citizenid -> source resolution for the delivery fan-out.
local player      = require 'bridge.server.player'
---@type table Mail persistence layer (server.mail.store): account-row CRUD + in-row JSON message ops.
local store       = require 'server.mail.store'
---@type table Accounts-engine persistence (server.accounts.store): cross-app contact-uniqueness lookups.
local acctStore   = require 'server.accounts.store'
---@type table Accounts-engine actions (server.accounts.actions): credential mirror + password verify.
local acctActions = require 'server.accounts.actions'
---@type table Home-screen badge engine (server.badges.init): recomputes + pushes unread counts.
local badges      = require 'server.badges.init'
---@type table Media URL ownership checks for attachments rendered by mail recipients.
local mediaGuard  = require 'server.media.guard'

---@type table Mail app config (configs/mail.lua): domain, length limits, per-player caps.
local mailCfg = config.Mail

---@type table Actions module; the table returned at end of file.
local actions = {}

-- Server-side compose caps.
---@type integer Max recipients accepted per send/draft; larger lists are rejected outright.
local MAX_RECIPIENTS = 20
---@type integer Subject cap (chars); longer subjects are truncated.
local MAX_SUBJECT_LEN = 200
---@type integer Body cap (chars); longer bodies are truncated.
local MAX_BODY_LEN = 10000
---@type integer Sign-in password length bound: the larger of mailCfg.MaxPasswordLength and 64.
local MAX_SIGNIN_PASSWORD_LEN = math.max(mailCfg.MaxPasswordLength, 64)
---@type integer Max attachments accepted per send/draft; extras are dropped.
local MAX_ATTACHMENTS = 5
---@type integer Attachment URL cap (chars).
local MAX_ATTACHMENT_URL_LEN = 512
---@type integer Attachment display-name / note-title cap (chars).
local MAX_ATTACHMENT_NAME_LEN = 80
---@type integer Attached note body cap (chars).
local MAX_ATTACHMENT_NOTE_LEN = 5000
---@type integer Action button label cap (chars).
local MAX_ACTION_LABEL_LEN = 32
---@type integer Action event name cap (chars).
local MAX_ACTION_EVENT_LEN = 128
---@type integer Encoded ceiling on the data an action button hands its event.
local MAX_ACTION_DATA_BYTES = 16384
---@type integer Minimum gap between action button taps, per character, so a double tap fires once.
local ACTION_GAP_MS = 1000

---@type integer Minimum gap between accepted sends, per character. A send rewrites the whole
---messages blob once per recipient, so this is the only thing bounding that cost per second.
local SEND_GAP_MS = 2000
---@type integer Minimum gap between accepted draft saves, per character. Saving a draft is a
---button, not an autosave, so a real composer never comes close.
local DRAFT_GAP_MS = 1000
---@type integer Minimum gap between accepted sign-ups, per character.
local SIGNUP_GAP_MS = 30000


---@type integer Rolling window over the per-message mailbox writes, and the calls allowed inside
---it. Each one decodes and re-encodes the whole messages blob, so the byte ceiling alone leaves
---the rate unbounded. A gap would break the list pages, which fire one call per selected mail:
---this sits above a select-all delete of a full MaxMessagesPerAccount mailbox.
local MUTATE_WINDOW_MS, MUTATE_PER_WINDOW = 60000, 300

local util = require 'server.util'
local ok, fail, trim = util.ok, util.fail, util.trim


---Resolves a connected source to its citizenid + display name.
---@param source number
---@return { cid: string, name: string }|nil
local function whois(source)
    local cid = player.getIdentifier(source)
    if not cid then return nil end
    return { cid = cid, name = player.getName(source) }
end


---Permissive email-format check for recipient addresses: an `@` with non-empty local + host
---parts, no whitespace, and a host that is the configured domain or contains at least one `.`.
---@param email string
---@return boolean
local function looksLikeEmail(email)
    if type(email) ~= 'string' then return false end
    if email:find('%s') then return false end
    local at = email:find('@', 1, true)
    if not at or at == 1 or at == #email then return false end
    local host = email:sub(at + 1)
    if host:lower() == mailCfg.Domain then return true end
    if not host:find('.', 1, true) then return false end
    return true
end

---Normalizes a player-supplied own address (bare username or full email) into the canonical
---local@Domain form. Foreign domains are rejected; the finished address is length-capped.
---@param raw any
---@return string|nil normalized
---@return table? refusal keyed refusal envelope when normalized is nil
local function validateEmail(raw)
    local trimmed = trim(raw):lower()
    local at = trimmed:find('@', 1, true)
    local localPart = at and trimmed:sub(1, at - 1) or trimmed
    if at and trimmed:sub(at + 1) ~= mailCfg.Domain then
        return nil, fail('mail.emailAddressesDomainOnly', 'Email addresses are @{domain} only',
            { domain = mailCfg.Domain })
    end
    if #localPart < 2 then
        return nil, fail('mail.usernameMustLeast2Characters', 'Username must be at least 2 characters')
    end
    if not localPart:match('^[%w][%w%.%_%-]*$') then
        return nil, fail('mail.lettersNumbersDotsDashes', 'Letters, numbers, dots, dashes and _ only')
    end
    local email = localPart .. '@' .. mailCfg.Domain
    if #email > mailCfg.MaxEmailLength then
        return nil, fail('mail.emailMustCharactersFewer', 'Email must be {n} characters or fewer',
            { n = mailCfg.MaxEmailLength })
    end
    return email, nil
end

---Validates password length against the configs/mail.lua bounds.
---@param raw any
---@return string|nil normalized
---@return table? refusal keyed refusal envelope when normalized is nil
local function validatePassword(raw)
    if type(raw) ~= 'string' then return nil, fail('mail.passwordRequired', 'Password is required') end
    if #raw < mailCfg.MinPasswordLength then
        return nil, fail('mail.passwordMustLeastCharacters', 'Password must be at least {n} characters',
            { n = mailCfg.MinPasswordLength })
    end
    if #raw > mailCfg.MaxPasswordLength then
        return nil, fail('mail.passwordMustCharactersFewer', 'Password must be {n} characters or fewer',
            { n = mailCfg.MaxPasswordLength })
    end
    return raw, nil
end

---Validates display-name length against the configs/mail.lua bounds; the name is trimmed.
---@param raw any
---@return string|nil normalized
---@return table? refusal keyed refusal envelope when normalized is nil
local function validateDisplayName(raw)
    local trimmed = trim(raw)
    if #trimmed < mailCfg.MinNameLength then
        return nil, fail('mail.nameMustLeastCharacters', 'Name must be at least {n} character{s}', {
            n = mailCfg.MinNameLength,
            s = mailCfg.MinNameLength == 1 and '' or 's',
        })
    end
    if #trimmed > mailCfg.MaxNameLength then
        return nil, fail('mail.nameMustCharactersFewer', 'Name must be {n} characters or fewer',
            { n = mailCfg.MaxNameLength })
    end
    return trimmed, nil
end

---Reshapes a hydrated store account into the React `MailAccount` shape; password_hash and the
---logged_in_citizens session list are omitted.
---@param acc { email: string, display_name: string }
---@return { id: string, name: string, email: string }
local function serializeAccount(acc)
    return { id = acc.email, name = acc.display_name, email = acc.email }
end

---Whitelists a client-supplied attachments list down to well-formed photo/audio/note/document
---entries; malformed entries are dropped and the result is capped at MAX_ATTACHMENTS. Document
---entries arrive as { kind = 'document', docId } references and are resolved into snapshots
---from the sender's own library here - content, flags and signature rows all read server-side,
---so a crafted payload can never plant fake content or signatures in a mailbox.
---@param raw any
---@param cid string|nil sender citizenid for document resolution; nil drops document references
---@return table[]|nil attachments nil when nothing valid remains
local function sanitizeAttachments(raw, cid)
    if type(raw) ~= 'table' then return nil end
    local out = {}
    for i = 1, #raw do
        if #out >= MAX_ATTACHMENTS then break end
        local a = raw[i]
        if type(a) == 'table' then
            local photoUrl, audioUrl
            if cid then
                photoUrl = mediaGuard.photo(cid, a.url)
                audioUrl = mediaGuard.voice(cid, a.url)
            else
                photoUrl = mediaGuard.https(a.url)
                audioUrl = mediaGuard.https(a.url)
            end
            if a.kind == 'photo' and photoUrl and #photoUrl <= MAX_ATTACHMENT_URL_LEN then
                out[#out + 1] = { kind = 'photo', url = photoUrl }
            elseif a.kind == 'audio' and audioUrl and #audioUrl <= MAX_ATTACHMENT_URL_LEN then
                local name = type(a.name) == 'string' and a.name or ''
                if #name > MAX_ATTACHMENT_NAME_LEN then name = name:sub(1, MAX_ATTACHMENT_NAME_LEN) end
                out[#out + 1] = { kind = 'audio', url = audioUrl, name = name, duration = tonumber(a.duration) or 0 }
            elseif a.kind == 'document' and cid and type(a.docId) == 'string' and a.docId ~= '' then
                local docsStore = require 'server.documents.store'
                local row = docsStore.getDoc(cid, a.docId)
                local shareableImage = row and row.kind == 'image' and mediaGuard.photo(cid, row.url) or nil
                if row and (row.kind ~= 'image' or shareableImage)
                    and not (row.locked == true or row.locked == 1) then
                    local sigs = nil
                    if row.kind == 'text' then
                        local list = docsStore.listSignatures(a.docId)
                        if #list > 0 then
                            sigs = {}
                            for j = 1, #list do
                                local s = list[j]
                                sigs[j] = { citizenid = s.citizenid, signer = s.signer, image = s.image, created_at = s.created_at }
                            end
                        end
                    end
                    out[#out + 1] = {
                        kind = 'document', docId = a.docId, name = row.name, docKind = row.kind,
                        content = row.content, url = shareableImage or row.url, size = tonumber(row.size) or 0,
                        source = row.source,
                        signable = not (row.signable == false or row.signable == 0),
                        signatures = sigs,
                    }
                end
            elseif a.kind == 'note' then
                local title = type(a.title) == 'string' and a.title or ''
                local body  = type(a.body)  == 'string' and a.body  or ''
                if #title > MAX_ATTACHMENT_NAME_LEN then title = title:sub(1, MAX_ATTACHMENT_NAME_LEN) end
                if #body  > MAX_ATTACHMENT_NOTE_LEN then body  = body:sub(1, MAX_ATTACHMENT_NOTE_LEN) end
                if title ~= '' or body ~= '' then
                    out[#out + 1] = { kind = 'note', title = title, body = body }
                end
            end
        end
    end
    return #out > 0 and out or nil
end

---Client-safe attachment list: document snapshots keep authentic signature rows (incl. the
---signer citizenid) in the stored mailbox row for re-delivery, but the citizenid never leaves
---the server - readers get signer name, image and timestamp only.
---@param atts table[]|nil
---@return table[]|nil
local function clientAttachments(atts)
    if type(atts) ~= 'table' then return atts end
    local out = {}
    for i = 1, #atts do
        local a = atts[i]
        if a.kind == 'document' and type(a.signatures) == 'table' then
            local copy = {}
            for k, v in pairs(a) do copy[k] = v end
            local sigs = {}
            for j = 1, #a.signatures do
                local s = a.signatures[j]
                sigs[j] = { signer = s.signer, image = s.image, signedAt = s.created_at }
            end
            copy.signatures = sigs
            out[i] = copy
        else
            out[i] = a
        end
    end
    return out
end

---@type table<string, integer> Vector type -> component count, for storing action data.
local VECTOR_SIZE = { vector2 = 2, vector3 = 3, vector4 = 4 }

---Copies action data into a JSON-safe shape. JSON would flatten a vector into a plain table that
---loses `.xyz` and vector maths, so each is tagged and rebuilt on the client before its event fires.
---@param v any
---@param depth integer nesting guard
---@return any
local function packActionData(v, depth)
    local size = VECTOR_SIZE[type(v)]
    if size then
        return { __vector = size, x = v.x, y = v.y, z = size >= 3 and v.z or nil, w = size == 4 and v.w or nil }
    end
    if type(v) ~= 'table' or depth > 16 then return v end
    local out = {}
    for k, item in pairs(v) do out[k] = packActionData(item, depth + 1) end
    return out
end

---Normalises a system mail's action button: the client event it fires once when tapped, the data
---handed to that event, and its label. Nil when the event name or the data is unusable.
---@param raw any
---@return { label: string, event: string, data: any, used: boolean }|nil
local function normaliseAction(raw)
    if type(raw) ~= 'table' then return nil end
    local event = trim(raw.event)
    if event == '' or #event > MAX_ACTION_EVENT_LEN then return nil end
    if not util.encodedSize(raw.data, MAX_ACTION_DATA_BYTES) then return nil end
    local label = trim(raw.label)
    if #label > MAX_ACTION_LABEL_LEN then label = label:sub(1, MAX_ACTION_LABEL_LEN) end
    return { label = label, event = event, data = packActionData(raw.data, 0), used = false }
end

---Reshapes a hydrated message into the React `MailMessage` shape, injecting `accountId` and
---filling fallbacks for rows written by older builds.
---@param accountEmail string
---@param msg table
---@return table
local function serializeMessage(accountEmail, msg)
    return {
        id        = msg.id,
        accountId = accountEmail,
        folder    = msg.folder    or 'inbox',
        from      = msg.from      or { name = '', email = '' },
        to        = msg.to        or {},
        subject   = msg.subject   or '',
        body      = msg.body      or '',
        sentAt    = msg.sentAt    or '',
        read      = msg.read      == true,
        flagged   = msg.flagged   == true,
        attachments = clientAttachments(msg.attachments),
        action    = type(msg.action) == 'table'
            and { label = msg.action.label or '', used = msg.action.used == true } or nil,
    }
end

---Public alias used by init.lua's mailbox export.
actions.serializeMessage = serializeMessage

---Delivery fan-out: resolves each entry's citizenid to a live source and, when online, sends
---the message as a live UI event, a phone banner, and a badge repush. Offline citizens are
---skipped.
---@param pushes { citizenid: string, message: table }[]
function actions.deliver(pushes)
    if type(pushes) ~= 'table' then return end
    for i = 1, #pushes do
        local src = player.getSourceByIdentifier(pushes[i].citizenid)
        if src then
            local msg  = pushes[i].message
            local from = msg.from or {}
            TriggerClientEvent('sd-phone:client:mail:received', src, msg)
            -- `link.mail` names the message this banner is about. The UI routes it through Mail's
            -- deeplink channel rather than seeding state, because the app is kept mounted between
            -- opens and would otherwise ignore anything handed to it after its first mount.
            TriggerClientEvent('sd-phone:client:notify', src, {
                app = 'mail', appId = 'mail',
                title = (from.name and from.name ~= '') and from.name or (from.email or 'Mail'),
                body  = (msg.subject and msg.subject ~= '') and msg.subject or 'New email',
                time  = 'now', quietInApp = true,
                link  = msg.id and {
                    mail = {
                        folder    = msg.folder or 'inbox',
                        msgId     = msg.id,
                        accountId = msg.accountId,
                    },
                } or nil,
            })
            badges.push(src)
        end
    end
end

---Loads the full Mail snapshot for the calling player: every account their citizenid is signed
---into and every message inside those accounts. Read-only.
---@param source number
---@return table
function actions.list(source)
    local me = whois(source); if not me then return fail('mail.playerNotFound', 'Player not found') end
    local accounts = store.listAccountsForCitizen(me.cid)

    local outAccounts = {}
    local outMessages = {}
    for i = 1, #accounts do
        local acc = accounts[i]
        outAccounts[i] = serializeAccount(acc)
        for j = 1, #acc.messages do
            outMessages[#outMessages + 1] = serializeMessage(acc.email, acc.messages[j])
        end
    end

    return ok({ accounts = outAccounts, messages = outMessages })
end

---Clears engine accounts left behind by mailboxes deleted before the delete path removed them.
---Such a row keeps the address reserved and a per-app slot spent against a mailbox that is gone.
---Only Mail can be repaired this way: phone_mail_accounts IS the mailbox, so its absence is
---proof. Photogram and Vibez seed their profile row lazily on first open, which makes a deleted
---account indistinguishable from one that registered and never opened the app.
---@return boolean ran true when the repair executed on this call
function actions.repairOrphanAccounts()
    return util.runOnce('accounts_orphan_mail_cleanup', function()
        local orphans = MySQL.query.await([[
            SELECT a.id, a.username FROM phone_app_accounts a
            LEFT JOIN phone_mail_accounts m
                   ON m.email = a.username COLLATE utf8mb4_unicode_ci
            WHERE a.app = 'mail' AND m.email IS NULL
        ]]) or {}
        for i = 1, #orphans do acctStore.deleteAccount(orphans[i].id) end
        if #orphans > 0 then
            print(('^3[sd-phone:mail]^0 released %d orphaned mail account name(s)'):format(#orphans))
        end
        return { removed = #orphans }
    end)
end

---Creates a brand-new email account and signs the caller straight into it. Every field is
---validated server-side; the password is hashed and mirrored into the accounts engine.
---@param source number
---@param payload { email?: string, password?: string, displayName?: string, phone?: string }
---@return table
function actions.signUp(source, payload)
    payload = payload or {}
    local me = whois(source); if not me then return fail('mail.playerNotFound', 'Player not found') end

    local email, ee = validateEmail(payload.email); if not email then return ee end
    local password, pe = validatePassword(payload.password); if not password then return pe end
    local displayName, ne = validateDisplayName(payload.displayName); if not displayName then return ne end

    if not util.cooldown(me.cid, 'mail:signUp', SIGNUP_GAP_MS) then
        return fail('mail.pleaseWaitBeforeCreatingAnother', 'Please wait before creating another account')
    end
    -- The same cap every other app gets, from configs/accounts.lua, but counted off Mail's own
    -- created_by_cid: it predates the accounts engine, so it is accurate for mailboxes made
    -- before the engine existed. Checked here rather than left to createAccount below, whose
    -- refusal that call discards - which is how a 4th mailbox used to get written with no
    -- engine account behind it, unrecoverable and missing from the Passwords app.
    local capped = acctActions.accountCapMessage('mail', store.countAccountsCreatedBy(me.cid))
    if capped then return capped end

    local phone = (tostring(payload.phone or '')):gsub('%D', '')
    if phone ~= '' and (#phone < 7 or #phone > 15) then
        return fail('mail.phoneNumberLooksInvalid', 'That phone number looks invalid')
    end
    -- The number is deliberately NOT unique: one person runs several mailboxes off one phone.
    -- Recovery stays possible because a reset is identified by the address, not by the number.
    if store.getAccount(email) then
        return fail('mail.emailAlreadyRegistered', 'That email is already registered')
    end

    local sessions = store.listAccountsForCitizen(me.cid)
    if #sessions >= mailCfg.MaxAccountsPerPlayer then
        return fail('mail.mostAccountsSignedIn', 'You can have at most {n} accounts signed in', { n = mailCfg.MaxAccountsPerPlayer })
    end

    if not store.insertAccount(email, store.hashPassword(password), displayName, me.cid) then
        return fail('mail.failedCreateAccount', 'Failed to create account')
    end
    store.addSession(email, me.cid)

    -- Ordered after the mail row on purpose: createAccount validates the recovery email against
    -- phone_mail_accounts, so the mailbox has to exist first. A refusal here leaves a mailbox
    -- with no engine account, which cannot be recovered or saved to Passwords, so it is undone.
    local acctRes = acctActions.createAccount('mail', {
        username = email, password = password, name = displayName,
        email = email, phone = phone ~= '' and phone or nil,
    }, me.cid)
    if not acctRes.success then
        store.deleteAccount(email)
        return acctRes
    end
    actions.drainPending(me.cid, email)

    local acc = store.getAccount(email)
    if not acc then return fail('mail.accountVanishedAfterCreation', 'Account vanished after creation') end
    return ok({ account = serializeAccount(acc) })
end

---Signs into an existing email account; any player who knows the password may sign in. The
---accounts engine is verified first, then the legacy hash column. Idempotent.
---@param source number
---@param payload { email?: string, password?: string }
---@return table
function actions.signIn(source, payload)
    payload = payload or {}
    local me = whois(source); if not me then return fail('mail.playerNotFound', 'Player not found') end

    local email, ee = validateEmail(payload.email); if not email then return ee end
    if type(payload.password) ~= 'string' or payload.password == '' then
        return fail('mail.passwordRequired', 'Password is required')
    end
    if #payload.password > MAX_SIGNIN_PASSWORD_LEN then
        return fail('mail.emailPasswordIncorrect', 'Email or password is incorrect')
    end

    local acc = store.getAccount(email)
    local valid = false
    if acc then
        local engineAcc = acctStore.getAccount('mail', email)
        if engineAcc then valid = acctActions.verifyPassword(engineAcc, payload.password) end
        if not valid then valid = acc.password_hash == store.hashPassword(payload.password) end
    end
    if not valid then
        return fail('mail.emailPasswordIncorrect', 'Email or password is incorrect')
    end

    local sessions = store.listAccountsForCitizen(me.cid)
    for i = 1, #sessions do
        if sessions[i].email == email then
            return ok({ account = serializeAccount(acc) })
        end
    end
    if #sessions >= mailCfg.MaxAccountsPerPlayer then
        return fail('mail.mostAccountsSignedIn', 'You can have at most {n} accounts signed in', { n = mailCfg.MaxAccountsPerPlayer })
    end

    store.addSession(email, me.cid)
    actions.drainPending(me.cid, email)
    return ok({ account = serializeAccount(store.getAccount(email) or acc) })
end

---Signs out of an account on this player's phone; the account survives, only the caller's
---session is dropped.
---@param source number
---@param payload { email?: string }
---@return table
function actions.signOut(source, payload)
    payload = payload or {}
    local me = whois(source); if not me then return fail('mail.playerNotFound', 'Player not found') end

    local email = trim(payload.email):lower()
    if email == '' then return fail('mail.emailRequired', 'Email is required') end

    store.removeSession(email, me.cid)
    return ok({ email = email })
end

---Sends a new message: persists a `sent` copy on the sender and an `inbox` copy on every
---recipient that exists, returning the signed-in citizenids for the delivery fan-out.
---@param source number
---@param payload { fromEmail?: string, to?: string[], subject?: string, body?: string }
---@return table
function actions.send(source, payload)
    payload = payload or {}
    local me = whois(source); if not me then return fail('mail.playerNotFound', 'Player not found') end

    if not util.cooldown(me.cid, 'mail:send', SEND_GAP_MS) then return fail('mail.slowDown', 'Slow down') end

    local fromEmail = trim(payload.fromEmail):lower()
    if fromEmail == '' then return fail('mail.senderAccountRequired', 'Sender account is required') end

    local sender = store.getAccount(fromEmail)
    if not sender then return fail('mail.senderAccountNotFound', 'Sender account not found') end

    if not lib.table.contains(sender.logged_in_citizens, me.cid) then
        return fail('mail.notSignedIntoAccount', 'You are not signed into that account')
    end

    local toRaw = payload.to or {}
    if type(toRaw) ~= 'table' or #toRaw == 0 then return fail('mail.leastOneRecipientRequired', 'At least one recipient is required') end
    if #toRaw > MAX_RECIPIENTS then return fail('mail.tooManyRecipients', 'Too many recipients') end

    local recipients = {}
    local seen = {}
    for i = 1, #toRaw do
        local addr = trim(toRaw[i]):lower()
        if addr ~= '' and #addr <= mailCfg.MaxEmailLength and not seen[addr] and looksLikeEmail(addr) then
            recipients[#recipients + 1] = addr
            seen[addr] = true
        end
    end
    if #recipients == 0 then return fail('mail.noValidRecipientAddresses', 'No valid recipient addresses') end

    local subject = trim(payload.subject)
    if #subject > MAX_SUBJECT_LEN then subject = subject:sub(1, MAX_SUBJECT_LEN) end
    local body    = type(payload.body) == 'string' and payload.body or ''
    if #body > MAX_BODY_LEN then body = body:sub(1, MAX_BODY_LEN) end
    local sentAt      = os.date('!%Y-%m-%dT%H:%M:%S')
    local attachments = sanitizeAttachments(payload.attachments, me.cid)

    local sentMessage = {
        id      = store.newId(),
        folder  = 'sent',
        from    = { name = sender.display_name, email = sender.email },
        to      = recipients,
        subject = subject,
        body    = body,
        sentAt  = sentAt,
        read    = true,
        flagged = false,
        attachments = attachments,
    }
    store.appendMessage(sender.email, sentMessage, mailCfg.MaxMessagesPerAccount)

    local pushes = {}
    for i = 1, #recipients do
        local addr = recipients[i]
        local recipient = store.getAccount(addr)
        if recipient then
            local inboxMessage = {
                id      = store.newId(),
                folder  = 'inbox',
                from    = { name = sender.display_name, email = sender.email },
                to      = recipients,
                subject = subject,
                body    = body,
                sentAt  = sentAt,
                read    = false,
                flagged = false,
                attachments = attachments,
            }
            store.appendMessage(addr, inboxMessage, mailCfg.MaxMessagesPerAccount)

            for j = 1, #recipient.logged_in_citizens do
                pushes[#pushes + 1] = {
                    citizenid = recipient.logged_in_citizens[j],
                    message   = serializeMessage(addr, inboxMessage),
                }
            end
        end
    end

    ---First-party send announcement, fired once per compose.
    TriggerEvent('sd-phone:server:mail:sent', {
        system    = false,
        id        = sentMessage.id,
        citizenid = me.cid,
        from      = { name = sender.display_name, email = sender.email },
        to        = recipients,
        subject   = subject,
        body      = body,
        sentAt    = sentAt,
    })

    return ok({
        sent   = serializeMessage(sender.email, sentMessage),
        pushes = pushes,
    })
end

---Composes and delivers mail as the system: no sender account, no ownership proof, no sent
---copy. Persists an `inbox` copy on every recipient that exists, then runs the fan-out.
---@param mail { to: string|string[], subject?: string, body?: string, from?: { name?: string, email?: string }, attachments?: (string|table)[], action?: { label?: string, event: string, data?: any } }
---@return table envelope; data.delivered counts recipient accounts that existed
function actions.systemSend(mail)
    if type(mail) ~= 'table' then return fail('mail.mailPayloadMustTable', 'Mail payload must be a table') end

    local toRaw = type(mail.to) == 'string' and { mail.to } or mail.to
    if type(toRaw) ~= 'table' or #toRaw == 0 then return fail('mail.leastOneRecipientRequired', 'At least one recipient is required') end
    if #toRaw > MAX_RECIPIENTS then return fail('mail.tooManyRecipients', 'Too many recipients') end

    local recipients = {}
    local seen = {}
    for i = 1, #toRaw do
        local addr = trim(toRaw[i]):lower()
        if addr ~= '' and #addr <= mailCfg.MaxEmailLength and not seen[addr] and looksLikeEmail(addr) then
            recipients[#recipients + 1] = addr
            seen[addr] = true
        end
    end
    if #recipients == 0 then return fail('mail.noValidRecipientAddresses', 'No valid recipient addresses') end

    local from = type(mail.from) == 'table' and mail.from or {}
    local fromName = trim(from.name)
    if fromName == '' then fromName = 'System' end
    if #fromName > mailCfg.MaxNameLength then fromName = fromName:sub(1, mailCfg.MaxNameLength) end
    local fromEmail = trim(from.email):lower()
    if fromEmail == '' then fromEmail = 'no-reply@' .. mailCfg.Domain end
    if #fromEmail > mailCfg.MaxEmailLength then fromEmail = fromEmail:sub(1, mailCfg.MaxEmailLength) end

    local subject = trim(mail.subject)
    if #subject > MAX_SUBJECT_LEN then subject = subject:sub(1, MAX_SUBJECT_LEN) end
    local body = type(mail.body) == 'string' and mail.body or ''
    if #body > MAX_BODY_LEN then body = body:sub(1, MAX_BODY_LEN) end
    local sentAt = os.date('!%Y-%m-%dT%H:%M:%S')

    -- Export ergonomics: a plain URL string is shorthand for a photo attachment (lb-phone's
    -- SendMail shape); tagged tables pass through to the same whitelist as player sends.
    local attachments = mail.attachments
    if type(attachments) == 'table' then
        local coerced = {}
        for i = 1, #attachments do
            local a = attachments[i]
            coerced[i] = type(a) == 'string' and { kind = 'photo', url = a } or a
        end
        attachments = sanitizeAttachments(coerced)
    else
        attachments = nil
    end
    local action = normaliseAction(mail.action)

    local delivered = 0
    local sentId
    local pushes = {}
    for i = 1, #recipients do
        local addr = recipients[i]
        local recipient = store.getAccount(addr)
        if recipient then
            local inboxMessage = {
                id      = store.newId(),
                folder  = 'inbox',
                from    = { name = fromName, email = fromEmail },
                to      = recipients,
                subject = subject,
                body    = body,
                sentAt  = sentAt,
                read    = false,
                flagged = false,
                attachments = attachments,
                action  = action,
            }
            store.appendMessage(addr, inboxMessage, mailCfg.MaxMessagesPerAccount)
            delivered = delivered + 1
            sentId = sentId or inboxMessage.id

            for j = 1, #recipient.logged_in_citizens do
                pushes[#pushes + 1] = {
                    citizenid = recipient.logged_in_citizens[j],
                    message   = serializeMessage(addr, inboxMessage),
                }
            end
        end
    end

    ---First-party send announcement (system shape), fired once before the fan-out.
    TriggerEvent('sd-phone:server:mail:sent', {
        system      = true,
        id          = sentId,
        from        = { name = fromName, email = fromEmail },
        to          = recipients,
        subject     = subject,
        body        = body,
        sentAt      = sentAt,
        delivered   = delivered,
        attachments = attachments,
    })

    actions.deliver(pushes)
    return ok({ delivered = delivered })
end

---Sends a system mail to an identity's first signed-in mailbox. With no mailbox it is held, the
---player is told to set Mail up, and it lands in the first account they create or sign into.
---@param citizenid string data identity of the recipient
---@param mail table systemSend payload; `to` is ignored
---@return table envelope; data.held is true when the mail was held rather than delivered
function actions.sendToCitizen(citizenid, mail)
    if type(mail) ~= 'table' then return fail('mail.mailPayloadMustTable', 'Mail payload must be a table') end
    if type(citizenid) ~= 'string' or citizenid == '' then
        return fail('mail.leastOneRecipientRequired', 'At least one recipient is required')
    end

    local copy = {}
    for k, v in pairs(mail) do copy[k] = v end
    copy.to = nil

    local account = store.listAccountsForCitizen(citizenid)[1]
    if account then
        copy.to = account.email
        return actions.systemSend(copy)
    end

    store.queuePending(citizenid, copy)
    local src = player.getSourceByIdentifier(citizenid)
    if src then
        local from = type(copy.from) == 'table' and trim(copy.from.name) or ''
        TriggerClientEvent('sd-phone:client:notify', src, {
            app = 'mail', appId = 'mail',
            title = from ~= '' and from or 'Mail',
            bodyKey = 'mail.mailWaitingSetUp', body = 'You have mail waiting. Set up Mail to read it.',
            time = 'now',
        })
    end
    return ok({ delivered = 0, held = true })
end

---Delivers every system mail held for an identity into `email`, oldest first.
---@param citizenid string
---@param email string mailbox the identity just signed into
function actions.drainPending(citizenid, email)
    local held = store.takePending(citizenid)
    for i = 1, #held do
        held[i].to = email
        actions.systemSend(held[i])
    end
end

---Saves the caller's compose as a draft on the sender account: same ownership proof and caps
---as `send`, persisting a single `drafts` copy and delivering to nobody.
---@param source number
---@param payload { fromEmail?: string, to?: string[], subject?: string, body?: string }
---@return table
function actions.saveDraft(source, payload)
    payload = payload or {}
    local me = whois(source); if not me then return fail('mail.playerNotFound', 'Player not found') end

    if not util.cooldown(me.cid, 'mail:saveDraft', DRAFT_GAP_MS) then return fail('mail.slowDown', 'Slow down') end

    local fromEmail = trim(payload.fromEmail):lower()
    if fromEmail == '' then return fail('mail.senderAccountRequired', 'Sender account is required') end

    local sender = store.getAccount(fromEmail)
    if not sender then return fail('mail.senderAccountNotFound', 'Sender account not found') end

    if not lib.table.contains(sender.logged_in_citizens, me.cid) then
        return fail('mail.notSignedIntoAccount', 'You are not signed into that account')
    end

    local recipients = {}
    local seen = {}
    local toRaw = payload.to
    if type(toRaw) == 'table' then
        if #toRaw > MAX_RECIPIENTS then return fail('mail.tooManyRecipients', 'Too many recipients') end
        for i = 1, #toRaw do
            local addr = trim(toRaw[i]):lower()
            if addr ~= '' and #addr <= mailCfg.MaxEmailLength and not seen[addr] and looksLikeEmail(addr) then
                recipients[#recipients + 1] = addr
                seen[addr] = true
            end
        end
    end

    local subject = trim(payload.subject)
    if #subject > MAX_SUBJECT_LEN then subject = subject:sub(1, MAX_SUBJECT_LEN) end
    local body = type(payload.body) == 'string' and payload.body or ''
    if #body > MAX_BODY_LEN then body = body:sub(1, MAX_BODY_LEN) end

    local draft = {
        id      = store.newId(),
        folder  = 'drafts',
        from    = { name = sender.display_name, email = sender.email },
        to      = recipients,
        subject = subject,
        body    = body,
        sentAt  = os.date('!%Y-%m-%dT%H:%M:%S'),
        read    = true,
        flagged = false,
        attachments = sanitizeAttachments(payload.attachments, me.cid),
    }
    store.appendMessage(sender.email, draft, mailCfg.MaxMessagesPerAccount)

    return ok({ draft = serializeMessage(sender.email, draft) })
end

---Ownership gate for the per-message mutators: the caller's citizenid must appear in the
---account's signed-in list.
---@param source number
---@param accountEmail string
---@return string|nil cid, table|nil err
local function requireOwnership(source, accountEmail)
    local me = whois(source); if not me then return nil, fail('mail.playerNotFound', 'Player not found') end
    if type(accountEmail) ~= 'string' or accountEmail == '' then return nil, fail('mail.accountEmailRequired', 'Account email is required') end
    -- Gated here rather than per action: getAccount below is the whole-blob decode every one of
    -- these mutators pays twice, and markRead/toggleFlag/move are reachable at unlimited rate.
    if not util.rateLimit(me.cid, 'mail:mutate', MUTATE_WINDOW_MS, MUTATE_PER_WINDOW) then
        return nil, fail('mail.slowDown', 'Slow down')
    end
    local acc = store.getAccount(accountEmail); if not acc then return nil, fail('mail.accountNotFound', 'Account not found') end
    if lib.table.contains(acc.logged_in_citizens, me.cid) then return me.cid, nil end
    return nil, fail('mail.notSignedIntoAccount', 'You are not signed into that account')
end

---Marks a message as read. Ownership-gated; a bogus message id is a no-op.
---@param source number
---@param payload { accountEmail?: string, messageId?: string }
---@return table
function actions.markRead(source, payload)
    payload = payload or {}
    local _, err = requireOwnership(source, payload.accountEmail); if err then return err end
    store.mutateMessage(payload.accountEmail, payload.messageId or '', function(m)
        m.read = true
        return m
    end)
    return ok()
end

---Marks many messages read in one write, so a "mark all" can't lose updates by racing N single
---writes. Ownership-gated; non-string, empty, unknown or already-read ids are skipped.
---@param source number
---@param payload { accountEmail?: string, messageIds?: string[] }
---@return table
function actions.markManyRead(source, payload)
    payload = payload or {}
    local _, err = requireOwnership(source, payload.accountEmail); if err then return err end
    local raw = payload.messageIds
    if type(raw) ~= 'table' then return ok() end
    local ids = {}
    for i = 1, #raw do
        if #ids >= mailCfg.MaxMessagesPerAccount then break end
        if type(raw[i]) == 'string' and raw[i] ~= '' then ids[#ids + 1] = raw[i] end
    end
    if #ids > 0 then store.markManyRead(payload.accountEmail, ids) end
    return ok()
end

---Toggles a message's flag. Ownership-gated; the new state derives from the stored message.
---@param source number
---@param payload { accountEmail?: string, messageId?: string }
---@return table
function actions.toggleFlag(source, payload)
    payload = payload or {}
    local _, err = requireOwnership(source, payload.accountEmail); if err then return err end
    store.mutateMessage(payload.accountEmail, payload.messageId or '', function(m)
        m.flagged = not (m.flagged == true)
        return m
    end)
    return ok()
end

---Uses a system mail's action button: consumes it once and returns the client event it names,
---with its data, for the caller's client to fire. Ownership-gated.
---@param source number
---@param payload { accountEmail?: string, messageId?: string }
---@return table envelope; data is { event, data, message } on success
function actions.runAction(source, payload)
    payload = payload or {}
    local cid, err = requireOwnership(source, payload.accountEmail); if err then return err end
    if not util.cooldown(cid, 'mail:action', ACTION_GAP_MS) then return fail('mail.slowDown', 'Slow down') end

    local taken, updated
    store.mutateMessage(payload.accountEmail, payload.messageId or '', function(m)
        if type(m.action) == 'table' and not m.action.used then
            taken = { event = m.action.event, data = m.action.data }
            m.action.used = true
        end
        updated = m
        return m
    end)
    if not taken then return fail('mail.actionAlreadyUsed', 'That has already been done') end
    return ok({ event = taken.event, data = taken.data, message = serializeMessage(payload.accountEmail, updated) })
end

---Moves a message to the bin, or hard-deletes it if it's already there. The flag clears on the
---way in. Ownership-gated.
---@param source number
---@param payload { accountEmail?: string, messageId?: string }
---@return table
function actions.moveToBin(source, payload)
    payload = payload or {}
    local _, err = requireOwnership(source, payload.accountEmail); if err then return err end
    store.mutateMessage(payload.accountEmail, payload.messageId or '', function(m)
        if m.folder == 'bin' then return nil end
        m.folder = 'bin'
        m.flagged = false
        return m
    end)
    return ok()
end

---Moves a message to a specific folder, whitelist-checked against the five real folders.
---Moving into the bin clears the flag. Ownership-gated.
---@param source number
---@param payload { accountEmail?: string, messageId?: string, folder?: string }
---@return table
function actions.move(source, payload)
    payload = payload or {}
    local _, err = requireOwnership(source, payload.accountEmail); if err then return err end
    local folder = payload.folder
    if folder ~= 'inbox' and folder ~= 'drafts' and folder ~= 'sent' and folder ~= 'spam' and folder ~= 'bin' then
        return { success = false, messageKey = 'mail.badFolder', message = 'Bad folder' }
    end
    store.mutateMessage(payload.accountEmail, payload.messageId or '', function(m)
        -- Returning nil would hard-delete; a same-folder move must be a no-op.
        if m.folder == folder then return m end
        m.folder = folder
        if folder == 'bin' then m.flagged = false end
        return m
    end)
    return ok()
end

---Hard-deletes a draft (and only a draft): used when an edited draft is re-sent or re-saved so
---the stale copy doesn't linger. Any other folder is left untouched. Ownership-gated.
---@param source number
---@param payload { accountEmail?: string, messageId?: string }
---@return table
function actions.discardDraft(source, payload)
    payload = payload or {}
    local _, err = requireOwnership(source, payload.accountEmail); if err then return err end
    store.mutateMessage(payload.accountEmail, payload.messageId or '', function(m)
        if m.folder ~= 'drafts' then return m end
        return nil
    end)
    return ok()
end

---Copies one attachment of a stored mail into the caller's own app: audio into Voice Memos,
---note into Notes, via each app's cap-checked deliverShare (which also live-pushes the added
---item). The attachment is read from the persisted row, never from the client, so only content
---that actually sits in the mailbox can be saved. Ownership-gated.
---@param source number
---@param payload { accountEmail?: string, messageId?: string, index?: number }
---@return table
function actions.saveAttachment(source, payload)
    payload = payload or {}
    local cid, err = requireOwnership(source, payload.accountEmail); if err then return err end

    local acc = store.getAccount(payload.accountEmail)
    if not acc then return fail('mail.accountNotFound', 'Account not found') end
    local msg
    for i = 1, #acc.messages do
        if acc.messages[i].id == payload.messageId then msg = acc.messages[i]; break end
    end
    if not msg then return fail('mail.messageNotFound', 'Message not found') end

    -- Client indices are zero-based over the message's attachments array.
    local att = type(msg.attachments) == 'table' and msg.attachments[(tonumber(payload.index) or -1) + 1] or nil
    if type(att) ~= 'table' then return fail('mail.attachmentNotFound', 'Attachment not found') end

    -- Each branch is idempotent: an identical item already in the target app short-circuits to
    -- success, so re-saving after an app reopen cannot pile up duplicates.
    if att.kind == 'photo' then
        local photoStore = require 'server.photos.store'
        if photoStore.hasUrl(cid, att.url) then return ok() end
        -- The URL comes from the stored row (not the player), so the URL-import config gate
        -- that guards photos:saveUrl does not apply here.
        local photosActions = require 'server.photos.actions'
        local res = photosActions.saveFromUrl(source, att.url, true)
        if not (res and res.success) then return fail('mail.couldNotSavePhotos', 'Could not save to Photos') end
        if res.data and res.data.photo then
            TriggerClientEvent('sd-phone:client:photos:added', source, res.data.photo)
        end
        return ok()
    end
    if att.kind == 'audio' then
        local voiceStore = require 'server.voicememos.store'
        if voiceStore.hasUrl(cid, att.url) then return ok() end
        local voiceActions = require 'server.voicememos.actions'
        if not voiceActions.deliverShare(source, { name = att.name, url = att.url, duration = att.duration }) then
            return fail('mail.couldNotSaveVoiceMemos', 'Could not save to Voice Memos')
        end
        return ok()
    end
    if att.kind == 'note' then
        local body = (type(att.body) == 'string' and att.body ~= '') and att.body or (att.title or '')
        local notesStore = require 'server.notes.store'
        if notesStore.hasBody(cid, body) then return ok() end
        local notesActions = require 'server.notes.actions'
        if not notesActions.deliverShare(source, { body = body, sketches = {}, images = {} }) then
            return fail('mail.couldNotSaveNotes', 'Could not save to Notes')
        end
        return ok()
    end
    if att.kind == 'document' then
        local docsStore = require 'server.documents.store'
        for _, row in ipairs(docsStore.listDocs(cid)) do
            if row.name == att.name and row.kind == (att.docKind or 'text') and (tonumber(row.size) or 0) == (tonumber(att.size) or 0) then
                return ok()
            end
        end
        -- The snapshot was built server-side at send time, so the signature rows re-attached
        -- by deliverShare are authentic. quiet: the saver initiated this, no banner needed.
        local docsActions = require 'server.documents.actions'
        if not docsActions.deliverShare(source, {
            name = att.name, kind = att.docKind, content = att.content, url = att.url,
            size = att.size, source = att.source, signable = att.signable,
            signatures = att.signatures, fromName = msg.from and msg.from.name or nil, quiet = true,
        }) then
            return fail('mail.couldNotSaveFiles', 'Could not save to Files')
        end
        return ok()
    end
    return fail('mail.attachmentCannotSaved', 'This attachment cannot be saved')
end

---Per-attachment saved flags for a stored mail, checked against the caller's own Photos /
---Voice Memos / Notes (photo+audio by URL, note by body). Ownership-gated; drives which save
---buttons the reader shows.
---@param source number
---@param payload { accountEmail?: string, messageId?: string }
---@return table
function actions.attachmentSaveStates(source, payload)
    payload = payload or {}
    local cid, err = requireOwnership(source, payload.accountEmail); if err then return err end

    local acc = store.getAccount(payload.accountEmail)
    if not acc then return fail('mail.accountNotFound', 'Account not found') end
    local msg
    for i = 1, #acc.messages do
        if acc.messages[i].id == payload.messageId then msg = acc.messages[i]; break end
    end
    if not msg then return fail('mail.messageNotFound', 'Message not found') end

    local atts = type(msg.attachments) == 'table' and msg.attachments or {}
    local saved = {}
    for i = 1, #atts do
        local a = atts[i]
        if a.kind == 'photo' then
            saved[i] = require('server.photos.store').hasUrl(cid, a.url)
        elseif a.kind == 'audio' then
            saved[i] = require('server.voicememos.store').hasUrl(cid, a.url)
        elseif a.kind == 'note' then
            local body = (type(a.body) == 'string' and a.body ~= '') and a.body or (a.title or '')
            saved[i] = require('server.notes.store').hasBody(cid, body)
        elseif a.kind == 'document' then
            local matched = false
            for _, row in ipairs(require('server.documents.store').listDocs(cid)) do
                if row.name == a.name and row.kind == (a.docKind or 'text') and (tonumber(row.size) or 0) == (tonumber(a.size) or 0) then
                    matched = true
                    break
                end
            end
            saved[i] = matched
        else
            saved[i] = false
        end
    end
    return ok({ saved = saved })
end

---Permanently deletes an account the caller is signed into, along with all its mail and
---sessions. Gated by the signed-in ownership check.
---@param source number
---@param payload { email?: string }
---@return table
function actions.deleteAccount(source, payload)
    payload = payload or {}
    local email = trim(payload.email or ''):lower()
    local _, err = requireOwnership(source, email); if err then return err end
    store.deleteAccount(email)
    -- The engine row owns the name and the per-app quota, so leaving it behind keeps the address
    -- reserved and the cap spent against an account that no longer exists.
    local acc = acctStore.getAccount('mail', email)
    if acc then acctStore.deleteAccount(acc.id) end
    return ok({ email = email })
end

---Both saved-email lists for a player: saved addresses and prompt-declined addresses.
---@param cid string
---@return table
local function savedEmailState(cid)
    return { emails = store.listSavedEmails(cid), declined = store.listDeclinedEmails(cid) }
end

---A player's saved compose addresses plus declined prompts. Read-only.
---@param source number
---@return table envelope
function actions.savedEmails(source)
    local who = whois(source); if not who then return fail('mail.noPlayer', 'No player') end
    return ok(savedEmailState(who.cid))
end

---Saves a compose address for the player. Replays are no-ops; the fresh list is returned.
---@param source number
---@param payload { email?: string }|nil
---@return table envelope
function actions.saveEmail(source, payload)
    local who = whois(source); if not who then return fail('mail.noPlayer', 'No player') end
    local email = type(payload) == 'table' and trim(payload.email) or nil
    email = email and email:lower() or nil
    if not email or #email == 0 or #email > 128 or not looksLikeEmail(email) then
        return fail('mail.invalidEmailAddress', 'Invalid email address')
    end
    if not store.addSavedEmail(who.cid, email, mailCfg.MaxSavedEmails) then
        return fail('mail.savedEmailLimitReached', 'Saved email limit reached')
    end
    return ok(savedEmailState(who.cid))
end

---Marks a save prompt as declined for an address, permanently suppressing future prompts
---for it. Idempotent.
---@param source number
---@param payload { email?: string }|nil
---@return table envelope
function actions.declineEmail(source, payload)
    local who = whois(source); if not who then return fail('mail.noPlayer', 'No player') end
    local email = type(payload) == 'table' and trim(payload.email) or nil
    email = email and email:lower() or nil
    if not email or #email == 0 or #email > 128 or not looksLikeEmail(email) then
        return fail('mail.invalidEmailAddress', 'Invalid email address')
    end
    store.declineSavedEmail(who.cid, email)
    return ok(savedEmailState(who.cid))
end

---Removes a saved compose address. Idempotent; the fresh list is returned.
---@param source number
---@param payload { email?: string }|nil
---@return table envelope
function actions.removeSavedEmail(source, payload)
    local who = whois(source); if not who then return fail('mail.noPlayer', 'No player') end
    local email = type(payload) == 'table' and trim(payload.email) or nil
    email = email and email:lower() or nil
    if not email or #email == 0 then return fail('mail.invalidEmailAddress', 'Invalid email address') end
    store.removeSavedEmail(who.cid, email)
    return ok(savedEmailState(who.cid))
end

return actions
