---@type table sd-phone config root (configs/config.lua).
local config   = require 'configs.config'
---@type table Player bridge (bridge.server.player): citizenid lookups from a server id.
local player   = require 'bridge.server.player'
---@type table Photos persistence layer (server.photos.store): photo/album row CRUD.
local store    = require 'server.photos.store'
---@type table AirShare handshake (server.share.core): offers a payload to a nearby phone.
local share    = require 'server.share.core'

---@type table Photos config (config.Photos): retention cap, album cap, name length bounds.
local photosCfg = config.Photos

---@type table Actions module; the table returned at end of file.
local actions = {}

local util = require 'server.util'
local ok, fail, isTruthy = util.ok, util.fail, util.truthy



---Shapes a DB photo row into the React `Photo` type; `favorite` goes through the TINYINT(1)
---guard and `created_at` passes through unchanged.
---@param row { id: string, url: string, favorite: any, created_at: any }
---@return table
local function shapePhoto(row)
    return {
        id        = row.id,
        url       = row.url,
        favorite  = isTruthy(row.favorite),
        createdAt = row.created_at,
    }
end

---@type integer Photos per page. A library of thousands used to arrive in one callback, which
---tripped oxmysql's oversized-result warning and mounted every tile at once.
local PAGE_SIZE <const> = 200

---One page of the caller's photos, newest first. An absent `cursor` means the first page, which
---also carries the smart-album counts. Read-only.
---@param source number player server id
---@param payload { cursor: string|nil, filter: 'favorites'|'videos'|nil, limit: number|nil }|nil
---@return table result { success, data = { photos, nextCursor, counts, canImport } }
function actions.list(source, payload)
    local cid = player.getIdentifier(source)
    if not cid then return fail('photos.playerNotFound', 'Player not found') end

    payload = type(payload) == 'table' and payload or {}
    local cursor = type(payload.cursor) == 'string' and payload.cursor ~= '' and payload.cursor or nil
    local filter = (payload.filter == 'favorites' or payload.filter == 'videos') and payload.filter or nil

    -- The client asks for a short first page so the opening animation is not competing with a
    -- few hundred tiles mounting, then full pages while scrolling. Clamped either way.
    local limit = math.floor(tonumber(payload.limit) or PAGE_SIZE)
    if limit < 1 then limit = 1 elseif limit > PAGE_SIZE then limit = PAGE_SIZE end

    -- One row past the page proves a further page exists; it is trimmed before shaping.
    local rows = store.listForCitizen(cid, cursor, limit, filter)
    local nextCursor
    if #rows > limit then
        local last = rows[limit]
        rows[limit + 1] = nil
        nextCursor = ('%d:%s'):format(math.floor(tonumber(last.ts) or 0), last.id)
    end

    local out = {}
    for i = 1, #rows do
        out[i] = shapePhoto(rows[i])
    end

    local data = { photos = out, nextCursor = nextCursor, canImport = actions.importEnabled() }
    -- Counts ride the first page only: the Recents/Favourites/Videos tiles need totals that a
    -- single page cannot report, and they do not change while paging.
    if not cursor then data.counts = store.countsFor(cid) end
    return ok(data)
end

---Shapes a DB photo row for a third-party reader. `isVideo` is added because kind lives in the
---URL rather than a column, and time is reported only as `timestamp`, a unix integer: the raw
---created_at column arrives in whatever shape the SQL driver decided on (oxmysql hands back a
---millisecond epoch, not the datetime text it was written as), which is not a shape to promise
---an outside caller.
---@param row { id: string, url: string, favorite: any, ts: any }
---@return table
local function shapeExportPhoto(row)
    return {
        id        = row.id,
        url       = row.url,
        isVideo   = store.isVideoUrl(row.url),
        favorite  = isTruthy(row.favorite),
        timestamp = math.floor(tonumber(row.ts) or 0),
    }
end

---A player's photos by owner id, newest first, for other resources. Unpaged on purpose: a picker
---wants one bounded list, so this is the first page and nothing else, clamped to PAGE_SIZE. Reads
---nothing the owner cannot already see. Always an array, empty when nothing resolves.
---@param citizenid string owner's framework per-character id
---@param opts { limit: number|nil, filter: 'favorites'|'videos'|nil }|nil
---@return table[] photos
function actions.listForCid(citizenid, opts)
    if type(citizenid) ~= 'string' or citizenid == '' then return {} end

    opts = type(opts) == 'table' and opts or {}
    local filter = (opts.filter == 'favorites' or opts.filter == 'videos') and opts.filter or nil

    local limit = tonumber(opts.limit)
    limit = (limit and util.finite(limit)) and math.floor(limit) or PAGE_SIZE
    if limit < 1 then limit = 1 elseif limit > PAGE_SIZE then limit = PAGE_SIZE end

    -- listForCitizen deliberately over-reads by one row to prove a further page exists; that probe
    -- row is not part of the page and would silently hand the caller limit + 1 photos.
    local rows = store.listForCitizen(citizenid, nil, limit, filter)
    rows[limit + 1] = nil

    local out = {}
    for i = 1, #rows do
        out[i] = shapeExportPhoto(rows[i])
    end
    return out
end

---@type integer Longest accepted photo URL in bytes, matching the phone_photos.url VARCHAR(512) column.
local MAX_URL_BYTES = 512

---True when player URL import is enabled (config.Photos.AllowImport); drives the Import button.
---@return boolean
function actions.importEnabled()
    return photosCfg.AllowImport == true
end

---True if `host` matches any entry in `list`: an exact hostname, or a '*.domain' subdomain
---wildcard (which also matches the bare domain). A non-table `list` counts as empty.
---@param host string lowercased hostname
---@param list any
---@return boolean
local function hostMatchesList(host, list)
    if type(list) ~= 'table' then return false end
    for _, raw in ipairs(list) do
        local entry = tostring(raw):lower()
        if lib.string.startsWith(entry, '*.') then
            local suffix = entry:sub(2) -- '.domain.com'
            if lib.string.endsWith(host, suffix) or host == entry:sub(3) then return true end
        elseif entry ~= '' and host == entry then
            return true
        end
    end
    return false
end

---Host check for player-supplied import URLs: HTTPS only, host on config.Photos.ImportAllowlist
---and not on ImportBlocklist. An empty allowlist rejects everything.
---@param url any
---@return boolean
function actions.isAllowedImportUrl(url)
    if type(url) ~= 'string' then return false end
    local host = url:lower():match('^https://([%w%.%-]+)[:/]') or url:lower():match('^https://([%w%.%-]+)$')
    if not host then return false end
    if hostMatchesList(host, photosCfg.ImportBlocklist) then return false end
    local allow = photosCfg.ImportAllowlist
    return type(allow) == 'table' and #allow > 0 and hostMatchesList(host, allow)
end

---Persists a photo URL against the caller: a non-empty HTTPS string within the column cap, with
---the gallery pruned back under config.Photos.MaxPhotosPerPlayer.
---@param source number player server id
---@param url string HTTPS URL of the hosted media
---@param trusted boolean|nil server-established provenance
---@return table result { success, data = { photo } }
function actions.saveFromUrl(source, url, trusted)

    local cid = player.getIdentifier(source)
    if not cid then
        print('^1[sd-phone:photos]^0 saveFromUrl: no citizenid for source')
        return fail('photos.playerNotFound', 'Player not found')
    end
    if type(url) ~= 'string' or url == '' then
        print('^1[sd-phone:photos]^0 saveFromUrl: empty url')
        return fail('photos.noUrl', 'No URL')
    end
    if not lib.string.startsWith(url, 'https://') then
        print('^1[sd-phone:photos]^0 saveFromUrl: url is not HTTPS')
        return fail('photos.invalidUrl', 'Invalid URL')
    end
    if #url > MAX_URL_BYTES then
        return fail('photos.invalidUrl', 'Invalid URL')
    end

    local id = store.newId()
    if not store.insertPhoto(id, cid, url, trusted) then
        print('^1[sd-phone:photos]^0 DB insert failed')
        return fail('photos.failedSavePhoto', 'Failed to save photo')
    end

    store.pruneOldest(cid, photosCfg.MaxPhotosPerPlayer)

    ---Fires the first-party photos:added hook once per saved photo; server-local and synchronous.
    TriggerEvent('sd-phone:server:photos:added', { source = source, citizenid = cid, id = id, url = url })

    return ok({
        photo = {
            id        = id,
            url       = url,
            favorite  = false,
            createdAt = os.date('!%Y-%m-%d %H:%M:%S'),
        },
    })
end

---Sets the favourite flag on a photo; `value` is coerced to a strict boolean and ownership is
---enforced by the store's citizenid scope. Idempotent.
---@param source number player server id
---@param photoId string photo row id
---@param value boolean desired favourite state
---@return table result { success, data = { id, favorite } }
function actions.setFavorite(source, photoId, value)
    local cid = player.getIdentifier(source)
    if not cid then return fail('photos.playerNotFound', 'Player not found') end
    if type(photoId) ~= 'string' or photoId == '' then return fail('photos.photoIdRequired', 'Photo id required') end
    if not store.setFavorite(photoId, cid, value and true or false) then
        return fail('photos.photoNotFound', 'Photo not found')
    end
    return ok({ id = photoId, favorite = value and true or false })
end

---Hard-deletes a photo the caller owns, clearing its album-membership rows.
---@param source number player server id
---@param photoId string photo row id
---@return table result { success, data = { id } }
function actions.delete(source, photoId)
    local cid = player.getIdentifier(source)
    if not cid then return fail('photos.playerNotFound', 'Player not found') end
    if type(photoId) ~= 'string' or photoId == '' then
        return fail('photos.photoIdRequired', 'Photo id required')
    end
    local url = store.deletePhoto(photoId, cid)
    if not url then
        return fail('photos.photoNotFound', 'Photo not found')
    end
    ---Fires the first-party photos:deleted hook once per owner-initiated delete; server-local and synchronous.
    TriggerEvent('sd-phone:server:photos:deleted', { source = source, citizenid = cid, id = photoId, url = url })
    return ok({ id = photoId })
end

---Offers one of the caller's photos to a nearby phone. Sends only the hosted URL.
---@param source number sender server id
---@param target any recipient server id, client-chosen and validated by share.request
---@param photoId any client-supplied photo row id
---@return table result { success, message? }
function actions.requestShare(source, target, photoId)
    local cid = player.getIdentifier(source)
    if not cid then return fail('photos.playerNotFound', 'Player not found') end
    if type(photoId) ~= 'string' or photoId == '' then return fail('photos.photoIdRequired', 'Photo id required') end

    local url = store.urlFor(photoId, cid)
    if not url then return fail('photos.photoNotFound', 'Photo not found') end

    local sent, refusal = share.request(source, target, 'photo', { url = url })
    if not sent then return refusal or fail('photos.couldNotSendRequest', 'Could not send request') end
    return ok({})
end

---Saves an accepted photo share into the recipient's gallery and pushes it live. Refused when
---they already hold that exact URL.
---@param targetSrc number recipient server id
---@param payload { url: string } stored share payload
---@return boolean delivered
---@return string? reason shown to the recipient when refused
function actions.deliverShare(targetSrc, payload)
    local cid = player.getIdentifier(targetSrc)
    if not cid then return false end

    local url = type(payload) == 'table' and payload.url or nil
    if type(url) ~= 'string' or url == '' then return false end
    if store.hasUrl(cid, url) then return false, 'Already in your gallery' end

    local id = store.newId()
    if not store.insertPhoto(id, cid, url, true) then return false end
    store.pruneOldest(cid, photosCfg.MaxPhotosPerPlayer)

    TriggerClientEvent('sd-phone:client:photos:added', targetSrc, {
        id        = id,
        url       = url,
        favorite  = false,
        createdAt = os.date('!%Y-%m-%d %H:%M:%S'),
    })
    return true
end

---Lists the caller's custom albums, each annotated with a photo count and a cover URL (newest
---photo in the album). Read-only.
---@param source number player server id
---@return table result { success, data = { albums } }
function actions.listAlbums(source)
    local cid = player.getIdentifier(source)
    if not cid then return fail('photos.playerNotFound', 'Player not found') end
    local rows = store.listAlbums(cid)
    local out = {}
    for i = 1, #rows do
        out[i] = {
            id        = rows[i].id,
            name      = rows[i].name,
            count     = tonumber(rows[i].count) or 0,
            cover     = rows[i].cover,
            createdAt = rows[i].created_at,
        }
    end
    return ok({ albums = out })
end

---Creates a custom album: the name is trimmed and bounded by
---config.Photos.Min/MaxAlbumNameLength, and the per-player album cap is enforced.
---@param source number player server id
---@param name string requested album name
---@return table result { success, data = { album } }
function actions.createAlbum(source, name)
    local cid = player.getIdentifier(source)
    if not cid then return fail('photos.playerNotFound', 'Player not found') end

    name = type(name) == 'string' and name:gsub('^%s+', ''):gsub('%s+$', '') or ''
    if #name < photosCfg.MinAlbumNameLength or #name > photosCfg.MaxAlbumNameLength then
        return fail('photos.albumNameMustCharacters', 'Album name must be {min}–{max} characters', {
            min = photosCfg.MinAlbumNameLength,
            max = photosCfg.MaxAlbumNameLength,
        })
    end
    if store.countAlbums(cid) >= photosCfg.MaxAlbumsPerPlayer then
        return fail('photos.albumLimitReached', 'Album limit reached')
    end

    local id = store.newId()
    if not store.createAlbum(id, cid, name) then
        return fail('photos.failedCreateAlbum', 'Failed to create album')
    end
    return ok({
        album = { id = id, name = name, count = 0, cover = nil, createdAt = os.date('!%Y-%m-%d %H:%M:%S') },
    })
end

---Deletes a custom album and its membership rows (never the photos in it); the store verifies
---ownership.
---@param source number player server id
---@param albumId string album row id
---@return table result { success, data = { id } }
function actions.deleteAlbum(source, albumId)
    local cid = player.getIdentifier(source)
    if not cid then return fail('photos.playerNotFound', 'Player not found') end
    if type(albumId) ~= 'string' or albumId == '' then return fail('photos.albumIdRequired', 'Album id required') end
    if not store.deleteAlbum(albumId, cid) then
        return fail('photos.albumNotFound', 'Album not found')
    end
    return ok({ id = albumId })
end

---Adds one or more photos to an album: every entry must be a non-empty string, the batch is
---capped at config.Photos.MaxPhotosPerPlayer, and foreign photo ids are silently skipped.
---@param source number player server id
---@param albumId string target album id
---@param photoIds string[] photo ids to add
---@return table result { success, data = { id, added } }
function actions.addPhotosToAlbum(source, albumId, photoIds)
    local cid = player.getIdentifier(source)
    if not cid then return fail('photos.playerNotFound', 'Player not found') end
    if type(albumId) ~= 'string' or albumId == '' then return fail('photos.albumIdRequired', 'Album id required') end
    if type(photoIds) ~= 'table' or #photoIds == 0 then return fail('photos.noPhotosSelected', 'No photos selected') end
    if #photoIds > photosCfg.MaxPhotosPerPlayer then return fail('photos.tooManyPhotos', 'Too many photos') end
    for i = 1, #photoIds do
        if type(photoIds[i]) ~= 'string' or photoIds[i] == '' then return fail('photos.photoIdRequired', 'Photo id required') end
    end
    if not store.addPhotosToAlbum(albumId, cid, photoIds) then
        return fail('photos.albumNotFound', 'Album not found')
    end
    return ok({ id = albumId, added = #photoIds })
end

---Removes a single photo from an album; ownership is enforced through the album row.
---@param source number player server id
---@param albumId string album row id
---@param photoId string photo row id
---@return table result { success, data = { albumId, photoId } }
function actions.removePhotoFromAlbum(source, albumId, photoId)
    local cid = player.getIdentifier(source)
    if not cid then return fail('photos.playerNotFound', 'Player not found') end
    if type(albumId) ~= 'string' or albumId == '' then return fail('photos.albumIdRequired', 'Album id required') end
    if type(photoId) ~= 'string' or photoId == '' then return fail('photos.photoIdRequired', 'Photo id required') end
    if not store.removePhotoFromAlbum(albumId, photoId, cid) then
        return fail('photos.notAlbum', 'Not in album')
    end
    return ok({ albumId = albumId, photoId = photoId })
end

---Lists the photos in one album, newest first; a foreign albumId reads as an empty album.
---Read-only.
---@param source number player server id
---@param albumId string album row id
---@return table result { success, data = { photos } }
function actions.listAlbumPhotos(source, albumId)
    local cid = player.getIdentifier(source)
    if not cid then return fail('photos.playerNotFound', 'Player not found') end
    if type(albumId) ~= 'string' or albumId == '' then return fail('photos.albumIdRequired', 'Album id required') end
    local rows = store.listAlbumPhotos(albumId, cid)
    local out = {}
    for i = 1, #rows do
        out[i] = shapePhoto(rows[i])
    end
    return ok({ photos = out })
end

return actions
