---@type table Bodycam config (configs/bodycam.lua): the Recording block read here.
local CFG      = require 'configs.bodycam'
---@type table Shared server helpers (server.util): envelopes, clamps, rate limits, cleanup.
local util     = require 'server.util'
---@type table MDT permissions (server.mdt.access): identity and the read gate.
local access   = require 'server.mdt.access'
---@type table Camera seats (server.mdt.cameras): the check that a terminal actually holds the
---camera it is filing footage against.
local cameras  = require 'server.mdt.cameras'
---@type table Fivemanage upload (server.photos.uploader): the same hosting path photos, voice
---memos and call recordings already use.
local uploader = require 'server.photos.uploader'
---@type table Upload throttles (server.photos.mediaLimit): the per-citizen size and cooldown
---ceiling, the same budget photos and voice memos are spent against.
local mediaLimit = require 'server.photos.mediaLimit'
---@type table Player bridge (bridge.server.player): the uploader's identity.
local player   = require 'bridge.server.player'
---@type table Photo library (server.photos.store): where a shared clip lands when it is sent to
---somebody's handset rather than their terminal.
local photos   = require 'server.photos.store'
---@type table Presigned upload slots (server.photos.presign): mint + claim for the direct path.
local presign  = require 'server.photos.presign'
---@type table HTTP upload ingest (server.media.httpUpload): single-use slots on the server's HTTP port.
local httpUpload = require 'server.media.httpUpload'
---@type table Notifications (server.notifications.init): the banner a recipient sees on the phone
---itself, so footage sent to somebody who is not looking at their terminal is still noticed.
local notifications = require 'server.notifications.init'

---@type table Recordings module; the table returned at end of file. A recording is what one
---terminal watched: the picture is rendered on the watching client, so there is no stream running
---when nobody is looking and nothing else that could be captured.
local recordings = {}

---@type table Recording knobs (configs/bodycam.lua Recording).
local REC = type(CFG.Recording) == 'table' and CFG.Recording or {}
---@type boolean Whether watches may be recorded at all.
local ENABLED = CFG.Enabled == true and REC.Enabled ~= false
---@type integer Seconds one recording may run.
local MAX_SECONDS = math.max(5, math.floor(tonumber(REC.MaxSeconds) or 300))
---@type integer Days a recording is kept, 0 meaning forever, which is the default.
local KEEP_DAYS = math.max(0, math.floor(tonumber(REC.KeepDays) or 0))
---@type integer Recordings one officer may keep before the oldest is dropped.
local MAX_PER_OFFICER = math.max(1, math.floor(tonumber(REC.MaxPerOfficer) or 1000))

---@type integer Ceiling on the assembled base64 payload, derived from the profile rather than
---guessed: the encoder cannot produce more than its own bitrate over its own maximum length, and
---base64 adds about a third. The slack covers container overhead and a bitrate overshoot.
local MAX_BYTES = math.floor(
    (math.max(200000, math.floor(tonumber(REC.Bitrate) or 1000000)) / 8) * MAX_SECONDS * 1.5
) + 1048576

---@type integer Slices one recording may be split into, so a client cannot announce a total that
---would have the server hold parts forever.
local MAX_SLICES <const> = 4096
---@type integer Milliseconds an unfinished assembly is kept before it is abandoned.
local ASSEMBLY_TTL_MS <const> = 120000
---@type integer Milliseconds between sweeps of abandoned assemblies.
local SWEEP_MS <const> = 30000

---@type table<integer, table> The recording each terminal is currently assembling, by server id.
---One at a time per terminal: the slices of a second recording would be indistinguishable from
---the first once they are in the same bucket.
local assembling = {}

---@type table<integer, boolean> Terminals with an upload already in flight.
local uploading = {}

---Drops whatever a terminal was assembling.
---@param src integer player server id
local function forget(src)
    assembling[src] = nil
end

---Lists a terminal's own recordings, newest first. Footage is filed against the officer it shows
---AND the terminal that took it, and the reader here is scoped to the latter: a dispatcher sees
---what they recorded. The officer it shows is on the row so it can be searched by unit.
recordings.list = access.gated('cameras.view', function(_src, payload, me)
    if not ENABLED then return util.ok({ enabled = false, recordings = {} }) end

    local officerCid = util.limitedString(payload.officerCid, 64)
    local rows

    if officerCid then
        rows = MySQL.query.await([[
            SELECT id, camera_id, kind, officer_cid, officer_name, callsign, plate, model,
                   watcher_cid, watcher_name, url, mime, duration, bytes, shared_by, created_at
            FROM phone_mdt_bodycam_recs
            WHERE watcher_cid = ? AND officer_cid = ?
            ORDER BY created_at DESC
            LIMIT 500
        ]], { me.citizenid, officerCid })
    else
        rows = MySQL.query.await([[
            SELECT id, camera_id, kind, officer_cid, officer_name, callsign, plate, model,
                   watcher_cid, watcher_name, url, mime, duration, bytes, shared_by, created_at
            FROM phone_mdt_bodycam_recs
            WHERE watcher_cid = ?
            ORDER BY created_at DESC
            LIMIT 500
        ]], { me.citizenid })
    end

    local out = {}
    for _, row in ipairs(rows or {}) do
        out[#out + 1] = {
            id          = row.id,
            cameraId    = row.camera_id,
            kind        = row.kind,
            officerCid  = row.officer_cid,
            officer     = row.officer_name,
            callsign    = row.callsign,
            plate       = row.plate,
            model       = row.model,
            watcher     = row.watcher_name,
            url         = row.url,
            mime        = row.mime,
            duration    = row.duration,
            bytes       = row.bytes,
            sharedBy    = row.shared_by,
            createdAt   = row.created_at,
        }
    end

    return util.ok({ enabled = true, recordings = out })
end)

---Shares one of the caller's own recordings: onto another officer's terminal, into their phone's
---photo library, or both. Copies rather than moves, so the sharer keeps their own copy and the
---recipient's is theirs to delete.
---
---Only ever the caller's OWN footage, and only by the id of a row they already hold: the URL is
---read from the row here rather than taken from the payload, so this cannot be used to post an
---arbitrary link into somebody else's phone.
recordings.share = access.audited('cameras.view', function(_src, payload, me)
    if not ENABLED then return util.fail('mdt.recordingNotAvailable', 'Recording is not available') end

    local id = tonumber(payload.id)
    local targetCid = util.limitedString(payload.citizenid, 64)
    local toMdt   = payload.toMdt ~= false
    local toPhone = payload.toPhone == true

    if not id then return util.fail('mdt.noSuchRecording', 'No such recording') end
    if not targetCid then return util.fail('mdt.pickSomebodySend', 'Pick somebody to send it to') end
    if not toMdt and not toPhone then return util.fail('mdt.pickWhereSend', 'Pick where to send it') end
    if targetCid == me.citizenid then return util.fail('mdt.alreadyRecording', 'That is already your recording') end

    local row = MySQL.single.await([[
        SELECT camera_id, kind, officer_cid, officer_name, callsign, plate, model,
               url, mime, duration, bytes
        FROM phone_mdt_bodycam_recs
        WHERE id = ? AND watcher_cid = ?
    ]], { math.floor(id), me.citizenid })
    if not row then return util.fail('mdt.noSuchRecording', 'No such recording') end

    local targetSrc = player.getSourceByIdentifier(targetCid)
    local sent = {}

    if toMdt then
        -- A second row rather than a shared one: the recipient can delete their copy without
        -- taking the sharer's evidence with it.
        MySQL.insert.await([[
            INSERT INTO phone_mdt_bodycam_recs
                (camera_id, kind, officer_cid, officer_name, callsign, plate, model,
                 watcher_cid, watcher_name, url, mime, duration, bytes, shared_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ]], {
            row.camera_id, row.kind, row.officer_cid, row.officer_name, row.callsign, row.plate,
            row.model, targetCid, '', row.url, row.mime, row.duration, row.bytes, me.name,
            os.time(),
        })
        sent[#sent + 1] = 'mdt'
        if targetSrc then TriggerClientEvent('sd-phone:client:mdt:recShared', targetSrc, { by = me.name }) end

        -- Addressed by citizenid rather than source, so footage sent to somebody who is offline is
        -- still waiting on their phone when they come back rather than being dropped on the floor.
        local kindName = row.kind == 'dashcam' and 'dashcam' or 'bodycam'
        local unitName = row.officer_name ~= '' and row.officer_name or 'a unit'
        notifications.notifyCid(targetCid, {
            app = 'mdt', appId = 'mdt', time = 'now',
            titleKey = 'mdt.mdtTitle', title = 'MDT',
            bodyKey = 'mdt.sentYouFootage', body = ('%s sent you %s footage of %s'):format(me.name, kindName, unitName),
            bodyVars = { name = me.name, kind = kindName, unit = unitName },
        })
    end

    if toPhone then
        -- The photo library reads a clip's kind back off the URL extension, and a recording is
        -- hosted as .webm, so it lands as a video with no extra flag to set.
        if not photos.hasUrl(targetCid, row.url) then
            photos.insertPhoto(photos.newId(), targetCid, row.url, true)
        end
        sent[#sent + 1] = 'phone'
        if targetSrc then
            TriggerClientEvent('sd-phone:client:photos:added', targetSrc,
                { id = nil, url = row.url, favorite = false })
        end

        notifications.notifyCid(targetCid, {
            app = 'photos', appId = 'photos', time = 'now',
            titleKey = 'photos.photosTitle', title = 'Photos',
            bodyKey = 'mdt.sharedVideo', body = ('%s shared a video with you'):format(me.name),
            bodyVars = { name = me.name },
        })
    end

    return util.ok({ sent = sent }), {
        entityType = 'camera',
        entityId   = row.camera_id,
        details    = { action = 'recordingShared', to = targetCid, by = me.citizenid, sent = sent },
    }
end)

---Deletes one of the caller's own recordings. Scoped to the terminal that took it: footage is
---evidence, and one dispatcher clearing another's is not a thing this offers.
recordings.delete = access.audited('cameras.view', function(_src, payload, me)
    if not ENABLED then return util.fail('mdt.recordingNotAvailable', 'Recording is not available') end

    local id = tonumber(payload.id)
    if not id then return util.fail('mdt.noSuchRecording', 'No such recording') end

    local affected = MySQL.update.await(
        'DELETE FROM phone_mdt_bodycam_recs WHERE id = ? AND watcher_cid = ?',
        { math.floor(id), me.citizenid }
    )
    if not affected or affected < 1 then return util.fail('mdt.noSuchRecording', 'No such recording') end

    return util.ok({ id = math.floor(id) }), {
        entityType = 'camera',
        entityId   = tostring(math.floor(id)),
        details    = { action = 'recordingDeleted', by = me.citizenid },
    }
end)

---Writes the finished row and trims the officer's history back to the cap.
---@param src integer uploading terminal
---@param url string hosted media URL
---@param meta table the opening announcement, already validated
---@param bytes integer assembled payload size
---@return table|nil row
local function saveRow(src, url, meta, bytes)
    local watcherCid = player.getIdentifier(src)
    if not watcherCid then return nil end

    local now = os.time()
    local id = MySQL.insert.await([[
        INSERT INTO phone_mdt_bodycam_recs
            (camera_id, kind, officer_cid, officer_name, callsign, plate, model,
             watcher_cid, watcher_name, url, mime, duration, bytes, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ]], {
        meta.cameraId, meta.kind, meta.officerCid, meta.officer, meta.callsign, meta.plate,
        meta.model, watcherCid, player.getName(src) or '', url, meta.mime, meta.duration,
        bytes, now,
    })
    if not id then return nil end

    -- Trim this terminal's history for this officer, oldest first. Done on write rather than on a
    -- timer so the cap is felt immediately and a busy shift cannot outrun it.
    MySQL.query.await([[
        DELETE FROM phone_mdt_bodycam_recs
        WHERE watcher_cid = ? AND id NOT IN (
            SELECT id FROM (
                SELECT id FROM phone_mdt_bodycam_recs
                WHERE watcher_cid = ?
                ORDER BY created_at DESC
                LIMIT ?
            ) keep
        )
    ]], { watcherCid, watcherCid, MAX_PER_OFFICER })

    return {
        id         = id,
        cameraId   = meta.cameraId,
        kind       = meta.kind,
        officerCid = meta.officerCid,
        officer    = meta.officer,
        callsign   = meta.callsign,
        plate      = meta.plate,
        model      = meta.model,
        watcher    = player.getName(src) or '',
        url        = url,
        mime       = meta.mime,
        duration   = meta.duration,
        bytes      = bytes,
        createdAt  = now,
    }
end

---The sentence an officer sees when the upload budget or pacing refuses them.
---@param why string|nil 'cooldown'|'busy'|'identity'|'budget'|'server'
---@return string message
local function refusal(why)
    if why == 'cooldown' then return 'Slow down a moment' end
    if why == 'busy' then return 'An upload is already in progress' end
    return 'Upload limit reached, try again later'
end

---Hosts a finished recording and files its row, reporting either outcome to the terminal.
---@param src integer uploading terminal
---@param dataUrl string the whole recording as a data:video/ URL
---@param meta table settled by buildMeta
---@param prepaid boolean|nil true when an HTTP slot already holds the budget for it
local function host(src, dataUrl, meta, prepaid)
    if not prepaid then
        local okLimit, why = mediaLimit.charge(src, #dataUrl)
        if not okLimit then
            TriggerClientEvent('sd-phone:client:mdt:recFailed', src, refusal(why))
            return
        end
    end

    local ext = meta.mime:find('mp4') and 'mp4' or 'webm'
    local filename = ('sdphone-bodycam-%s-%d.%s'):format(meta.officerCid, os.time(), ext)

    uploading[src] = true
    uploader.uploadMedia(dataUrl, filename, function(url, err)
        uploading[src] = nil
        if not url then
            print(('^1[sd-phone:mdt]^0 bodycam upload failed: %s'):format(tostring(err)))
            TriggerClientEvent('sd-phone:client:mdt:recFailed', src, err or 'Upload failed')
            return
        end

        local row = saveRow(src, url, meta, #dataUrl)
        if row then
            TriggerClientEvent('sd-phone:client:mdt:recSaved', src, row)
        else
            TriggerClientEvent('sd-phone:client:mdt:recFailed', src, 'Could not save the recording')
        end
    end)
end

---Assembles the slices in sequence order and hands the result to the uploader.
---
---Order matters and cannot be assumed: latent events are paced onto the wire independently and
---arrive in whatever order they finish, so the slices are keyed by their sequence number and only
---joined once every one of them is present.
---@param src integer uploading terminal
local function finish(src)
    local job = assembling[src]
    if not job then return end
    assembling[src] = nil

    if job.received < job.total then
        TriggerClientEvent('sd-phone:client:mdt:recFailed', src, 'The recording did not arrive in full')
        return
    end

    local parts = {}
    for seq = 1, job.total do
        local part = job.slices[seq]
        if not part then
            TriggerClientEvent('sd-phone:client:mdt:recFailed', src, 'The recording did not arrive in full')
            return
        end
        parts[seq] = part
    end

    -- Each slice is the base64 of a byte run whose length divides by 3, so no slice but the last
    -- carries padding and joining the strings reproduces the base64 of the whole file exactly.
    local payload = table.concat(parts)
    host(src, ('data:%s;base64,%s'):format(job.meta.mime, payload), job.meta)
end

---Settles everything the row will carry, from the camera the terminal is actually holding rather
---than from what it claims to have filmed. Both upload paths go through this and neither may
---re-derive any of it: the sliced path and the direct path differ only in how the bytes travel,
---so a second copy of these checks would be a second place for "which camera is this?" to be
---answered, and only one of them would get fixed.
---@param src integer uploading terminal
---@param payload table client-supplied announcement, untrusted
---@return table|nil meta, string|nil reason a player-facing sentence when it is refused
local function buildMeta(src, payload)
    payload = type(payload) == 'table' and payload or {}

    local id = util.limitedString(payload.cameraId, 96)
    if not id or not cameras.isWatching(src, id) then
        return nil, 'That camera is not open'
    end

    local kind, officerCid = cameras.split(id)
    if not kind or not officerCid then
        return nil, 'That camera is not open'
    end

    local duration = math.floor(tonumber(payload.duration) or 0)
    if duration < 1 then duration = 1 end
    if duration > MAX_SECONDS then duration = MAX_SECONDS end

    local mime = util.limitedString(payload.mime, 64) or 'video/webm'
    if not mime:find('^video/') then mime = 'video/webm' end

    return {
        cameraId   = id,
        kind       = kind,
        officerCid = officerCid,
        officer    = util.limitedString(payload.officer, 96) or officerCid,
        callsign   = util.limitedString(payload.callsign, 16),
        plate      = util.limitedString(payload.plate, 16),
        model      = util.limitedString(payload.model, 64),
        mime       = mime,
        duration   = duration,
    }
end

if ENABLED then
    ---React -> server: a terminal announcing a finished recording and how many slices it is about
    ---to send.
    ---@param payload table { cameraId, mime, duration, total }
    RegisterNetEvent('sd-phone:server:mdt:recBegin', function(payload)
        local src = source
        payload = type(payload) == 'table' and payload or {}

        if uploading[src] then
            TriggerClientEvent('sd-phone:client:mdt:recFailed', src, 'An upload is already in progress')
            return
        end

        local meta, reason = buildMeta(src, payload)
        if not meta then
            TriggerClientEvent('sd-phone:client:mdt:recFailed', src, reason)
            return
        end

        local total = math.floor(tonumber(payload.total) or 0)
        if total < 1 or total > MAX_SLICES then
            TriggerClientEvent('sd-phone:client:mdt:recFailed', src, 'That recording is too long to keep')
            return
        end

        assembling[src] = {
            total    = total,
            received = 0,
            bytes    = 0,
            slices   = {},
            at       = GetGameTimer(),
            meta     = meta,
        }
    end)

    ---React -> server: one slice of the finished recording. Latent, so it is paced onto the wire
    ---rather than blocking the net thread, which is exactly why it carries its own sequence number.
    ---@param payload table { seq, part }
    RegisterNetEvent('sd-phone:server:mdt:recSlice', function(payload)
        local src = source
        local job = assembling[src]
        if not job then return end

        payload = type(payload) == 'table' and payload or {}
        local seq  = math.floor(tonumber(payload.seq) or 0)
        local part = payload.part

        if seq < 1 or seq > job.total or type(part) ~= 'string' or part == '' then return end
        if job.slices[seq] ~= nil then return end

        job.bytes = job.bytes + #part
        if job.bytes > MAX_BYTES then
            assembling[src] = nil
            TriggerClientEvent('sd-phone:client:mdt:recFailed', src, 'That recording is too large to keep')
            return
        end

        job.slices[seq] = part
        job.received = job.received + 1
        job.at = GetGameTimer()

        if job.received >= job.total then finish(src) end
    end)

    ---React -> server: abandon whatever was being assembled, for a terminal that gave up midway.
    RegisterNetEvent('sd-phone:server:mdt:recCancel', function()
        forget(source)
    end)

    -- Direct upload. A recording is the largest thing this phone ever moves - five minutes at the
    -- configured bitrate is around 94 MB, some fifty times a camera clip - and the sliced path
    -- puts every byte of it on the ENet reliable channel, where it costs the uploading officer
    -- packet loss for as long as it runs. The terminal uploads to the CDN itself instead and
    -- reports back where it landed; the sliced path below stays as the fallback.

    ---@type integer Largest object a claim may point at, in raw bytes. MAX_BYTES is the ceiling on
    ---the base64 payload, and base64 is four bytes for every three, so the file itself is
    ---three-quarters of it. Deriving it keeps the two paths accepting the same recordings.
    local MAX_DIRECT_BYTES <const> = math.floor(MAX_BYTES * 0.75)

    ---@type table<integer, table> Meta settled at slot time, waiting for the claim that follows.
    ---One per terminal, replaced by a later slot, and dropped when the terminal leaves.
    local pendingDirect = {}

    ---React -> server: a terminal is about to upload a finished recording itself and wants a slot.
    ---Everything the row will carry is settled and kept HERE, at the moment the terminal is known
    ---to hold the camera - not read back off the claim. A claim that carried its own meta would
    ---let a terminal film one camera and file it against another.
    lib.callback.register('sd-phone:server:mdt:recSlot', function(src, payload)
        if not presign.available() then return { success = false, code = 'unavailable' } end
        if uploading[src] or assembling[src] then return { success = false, code = 'busy' } end

        local meta, reason = buildMeta(src, payload)
        if not meta then return { success = false, code = 'refused', message = reason } end

        local p = promise.new()
        presign.mint(src, { maxBytes = MAX_DIRECT_BYTES },
            function(url, code) p:resolve({ url = url, code = code }) end)
        local res = Citizen.Await(p)
        if not res.url then return { success = false, code = res.code or 'provider' } end

        pendingDirect[src] = meta
        return { success = true, data = { url = res.url } }
    end)

    ---React -> server: the terminal finished its upload and reports where it landed. The URL is
    ---untrusted until presign.claim has proved it is a fresh object in this server's own bucket;
    ---the meta comes from the slot, never from this call.
    lib.callback.register('sd-phone:server:mdt:recDone', function(src, payload)
        local meta = pendingDirect[src]
        pendingDirect[src] = nil
        if not meta then return { success = false, code = 'no-slot' } end

        payload = type(payload) == 'table' and payload or {}

        local p = promise.new()
        presign.claim(src, payload.url,
            { maxBytes = MAX_DIRECT_BYTES, kinds = { video = true } },
            function(url, code, bytes)
            p:resolve({ url = url, code = code, bytes = bytes })
        end)
        local res = Citizen.Await(p)
        if not res.url then
            print(('^1[sd-phone:mdt]^0 direct bodycam claim refused (%s) for %s')
                :format(tostring(res.code), tostring(payload.url)))
            return { success = false, code = res.code }
        end

        -- The true file size. The sliced path stores #dataUrl, which is the base64 and so about a
        -- third larger than the recording; older rows keep that figure rather than being rewritten.
        local row = saveRow(src, res.url, meta, res.bytes)
        if not row then return { success = false, code = 'save-failed' } end

        TriggerClientEvent('sd-phone:client:mdt:recSaved', src, row)
        return { success = true }
    end)

    ---React -> server: open an HTTP upload slot for a finished recording. Everything the row will
    ---carry is settled here from the camera the terminal is holding, so the body is only the video.
    ---@param payload table { cameraId, mime, duration, officer, callsign, plate, model }
    lib.callback.register('sd-phone:server:mdt:recHttpSlot', function(src, payload)
        local meta, reason = buildMeta(src, payload)
        if not meta then
            TriggerClientEvent('sd-phone:client:mdt:recFailed', src, reason)
            return { success = false, code = 'refused' }
        end

        local slot, why = nil, 'busy'
        if not uploading[src] and not assembling[src] then
            slot, why = httpUpload.mint(src, MAX_BYTES, function(owner, body)
                if not body:find('^data:video/') then
                    TriggerClientEvent('sd-phone:client:mdt:recFailed', owner, 'The recording did not arrive in full')
                    return { success = false }
                end
                host(owner, body, meta, true)
                return { success = true }
            end)
        end
        if not slot then
            TriggerClientEvent('sd-phone:client:mdt:recFailed', src, refusal(why))
            return { success = false, code = why }
        end
        return { success = true, data = slot }
    end)

    util.onCleanup(function(src)
        pendingDirect[src] = nil
    end)

    -- Abandons assemblies whose terminal stopped sending, so a dropped upload cannot hold its
    -- slices in memory until the resource restarts.
    CreateThread(function()
        while true do
            Wait(SWEEP_MS)
            local now = GetGameTimer()
            for src, job in pairs(assembling) do
                if (now - job.at) > ASSEMBLY_TTL_MS then assembling[src] = nil end
            end
        end
    end)

    -- Drops recordings past the keep window, on its own slow thread. Footage nobody has come back
    -- for in a month is storage, not evidence.
    CreateThread(function()
        if KEEP_DAYS <= 0 then return end
        Wait(180000)
        while true do
            local cutoff = os.time() - (KEEP_DAYS * 86400)
            local removed = MySQL.update.await(
                'DELETE FROM phone_mdt_bodycam_recs WHERE created_at < ?', { cutoff }
            )
            if type(removed) == 'number' and removed > 0 then
                print(('^2[sd-phone:mdt]^0 pruned %d bodycam recording(s) past the keep window'):format(removed))
            end
            Wait(3600000)
        end
    end)

    util.onCleanup(function(src)
        forget(src)
        uploading[src] = nil
    end)
end

---Whether recording is switched on at all, for the routes above it.
---@return boolean
function recordings.enabled() return ENABLED end

return recordings
