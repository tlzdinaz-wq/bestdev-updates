---@type table Framework detection (bridge.shared.framework): name ('qb'|'esx') + live core handle.
local framework = require 'bridge.shared.framework'
---@type table Garage bridge (bridge.server.garages): the active system's column profile, so a
---vehicle's garage and state are read the same way here as in the Garages app.
local garages = require 'bridge.server.garages'

---@type table Records module; the table returned at end of file. Read-only reads of the
---FRAMEWORK's own citizen and vehicle tables, so framework-shape knowledge stays in bridge/ and
---never leaks into server/mdt/. Nothing here writes, and no framework table is ever ALTERed.
local records = {}

---@type { table: string, idCol: string } Framework citizen table: QBCore/QBox key characters by
---citizenid in `players`, ESX by identifier in `users`, ox_core by charId in `characters`, ND by
---charid in `nd_characters`.
---
---ox_core and ND both also HAVE an account table (`users` and `nd_users`), one row per player
---rather than per character - reaching ESX's branch here would read the wrong rows entirely.
local PEOPLE
if framework.name == 'vfw' then
    PEOPLE = { table = 'characters',    idCol = 'identifier' }
elseif framework.name == 'esx' then
    PEOPLE = { table = 'users',         idCol = 'identifier' }
elseif framework.name == 'ox' then
    PEOPLE = { table = 'characters',    idCol = 'charId' }
elseif framework.name == 'nd' then
    PEOPLE = { table = 'nd_characters', idCol = 'charid' }
else
    PEOPLE = { table = 'players',       idCol = 'citizenid' }
end

---@type { table: string, idCol: string } Framework ownership table, picked the same way
---bridge/server/garages.lua picks it.
local VEHICLES
if framework.name == 'vfw' then
    VEHICLES = { table = 'owned_vehicles',  idCol = 'owner' }
elseif framework.name == 'esx' then
    VEHICLES = { table = 'owned_vehicles',  idCol = 'owner' }
elseif framework.name == 'ox' then
    VEHICLES = { table = 'vehicles',        idCol = 'owner' }
elseif framework.name == 'nd' then
    VEHICLES = { table = 'nd_vehicles',     idCol = 'owner' }
else
    VEHICLES = { table = 'player_vehicles', idCol = 'citizenid' }
end

---@type string[] Columns a model name may live in, in preference order. `vehicle` is last on
---purpose: qb/QBox keep a plain name there, but ESX keeps the whole properties blob under the same
---name, so a fork carrying a real model column should win over it.
local MODEL_COLS = { 'model', 'vehicle_name', 'name', 'vehicle' }

---@type integer Characters below which a term is not a filter at all, so the caller is browsing and
---the list comes back unfiltered rather than empty.
local MIN_TERM <const> = 2

---@type table<string, table<string, boolean>>|nil Present columns per table, resolved on first use.
local columnCache = {}

---The set of columns a table actually has, read once per table and memoised. An unknown table
---resolves to an empty set, which every caller treats as "that column is not available".
---@param tbl string table name
---@return table<string, boolean>
local function columnsOf(tbl)
    local hit = columnCache[tbl]
    if hit then return hit end
    local out = {}
    local ok, rows = pcall(function()
        return MySQL.query.await([[
            SELECT COLUMN_NAME AS name FROM information_schema.columns
            WHERE table_schema = DATABASE() AND table_name = ?
        ]], { tbl })
    end)
    if ok and type(rows) == 'table' then
        for i = 1, #rows do out[rows[i].name] = true end
    end
    columnCache[tbl] = out
    return out
end

---Ordering for a citizen list. Recency reads far better than an identifier for a browse list, and
---the recency column is indexed where it exists, so the page comes off the index instead of a
---filesort over the whole table. Sorting by name is deliberately not offered: on the qb family the
---name lives inside the `charinfo` text blob, so it can only be reached through JSON_EXTRACT, which
---no index can serve.
---@param tbl string table the list is read from
---@param recent string recency column to prefer
---@param fallback string indexed column to fall back to
---@return string order SQL fragment
local function citizenOrder(tbl, recent, fallback)
    if columnsOf(tbl)[recent] then return ('`%s` DESC'):format(recent) end
    return ('`%s` ASC'):format(fallback)
end

---The column a vehicle's model name lives in on this framework, or nil when none of the known
---candidates exist (ESX forks that keep the model inside the `vehicle` JSON blob).
---@return string|nil
local function modelColumn()
    local have = columnsOf(VEHICLES.table)
    for i = 1, #MODEL_COLS do
        if have[MODEL_COLS[i]] then return MODEL_COLS[i] end
    end
    return nil
end

---Trims a value to a plain string; a non-string coerces to ''.
---@param v any
---@return string
local function str(v)
    if type(v) ~= 'string' then return v ~= nil and tostring(v) or '' end
    return (v:gsub('^%s+', ''):gsub('%s+$', ''))
end

---Decodes a JSON column that oxmysql may hand back already decoded.
---@param raw any
---@return table
local function decode(raw)
    if type(raw) == 'table' then return raw end
    if type(raw) ~= 'string' or raw == '' then return {} end
    local ok, out = pcall(json.decode, raw)
    return (ok and type(out) == 'table') and out or {}
end

---Builds the normalised citizen shape from a QBCore/QBox `players` row.
---@param row table
---@return table citizen
local function qbCitizen(row)
    local info = decode(row.charinfo)
    local meta = decode(row.metadata)
    local jb   = decode(row.job)

    local first = str(info.firstname)
    local last  = str(info.lastname)
    local name  = str((first .. ' ' .. last))

    local licences = {}
    if type(meta.licences) == 'table' then
        for key, held in pairs(meta.licences) do
            if held == true and type(key) == 'string' then licences[#licences + 1] = key end
        end
    end
    if type(meta.licenses) == 'table' then
        for key, held in pairs(meta.licenses) do
            if held == true and type(key) == 'string' then licences[#licences + 1] = key end
        end
    end

    return {
        citizenid   = row.citizenid,
        name        = name ~= '' and name or row.citizenid,
        firstname   = first,
        lastname    = last,
        dob         = str(info.birthdate) ~= '' and str(info.birthdate) or str(info.dateofbirth),
        sex         = str(info.gender) ~= '' and str(info.gender) or str(info.sex),
        phone       = str(info.phone),
        nationality = str(info.nationality),
        job         = str(jb.name),
        jobGrade    = type(jb.grade) == 'table' and (tonumber(jb.grade.level) or 0) or (tonumber(jb.grade) or 0),
        licences    = licences,
        fingerprint = str(meta.fingerprint),
        bloodtype   = str(meta.bloodtype),
        callsign    = str(meta.callsign),
    }
end

---Licence keys an ESX character holds, read from esx_license's `user_licenses` table and folded
---onto the qb vocabulary: `drive`, `drive_bike` and `drive_truck` all become `driver`, anything
---else keeps its type name. Empty when the table is not installed. One query, so only the single
---citizen read calls it; the paged search never does.
---@param identifier string ESX identifier
---@return string[] licences
local function esxLicences(identifier)
    if not next(columnsOf('user_licenses')) then return {} end
    local ok, rows = pcall(function()
        return MySQL.query.await('SELECT `type` FROM user_licenses WHERE owner = ?', { identifier })
    end)
    if not ok or type(rows) ~= 'table' then return {} end
    local seen, out = {}, {}
    for i = 1, #rows do
        local key = str(rows[i].type)
        if key:sub(1, 5) == 'drive' then key = 'driver' end
        if key ~= '' and not seen[key] then
            seen[key] = true
            out[#out + 1] = key
        end
    end
    return out
end

---Builds the normalised citizen shape from an ESX `users` row.
---@param row table
---@return table citizen
local function esxCitizen(row)
    local first = str(row.firstname)
    local last  = str(row.lastname)
    local name  = str(first .. ' ' .. last)
    local meta  = decode(row.metadata)

    return {
        citizenid   = row.identifier,
        name        = name ~= '' and name or row.identifier,
        firstname   = first,
        lastname    = last,
        dob         = str(row.dateofbirth),
        sex         = str(row.sex),
        phone       = str(row.phone_number),
        nationality = '',
        job         = str(row.job),
        jobGrade    = tonumber(row.job_grade) or 0,
        licences    = {},
        fingerprint = str(meta.fingerprint),
        bloodtype   = '',
        callsign    = '',
    }
end

---Builds the normalised citizen shape from an ND `nd_characters` row. charid is an INT column, so
---it is stringified on the way out to match the identifier every caller carries.
---@param row table
---@return table citizen
local function ndCitizen(row)
    local cid   = tostring(row.charid)
    local first = str(row.firstname)
    local last  = str(row.lastname)
    local name  = str(first .. ' ' .. last)
    local meta  = decode(row.metadata)

    local activeJob, activeRank = '', 0
    for groupName, group in pairs(decode(row.groups)) do
        if type(groupName) == 'string' and type(group) == 'table' and group.isJob then
            activeJob, activeRank = groupName, tonumber(group.rank) or 0
            break
        end
    end

    return {
        citizenid   = cid,
        name        = name ~= '' and name or cid,
        firstname   = first,
        lastname    = last,
        dob         = str(row.dob),
        sex         = str(row.gender),
        phone       = str(row.phonenumber),
        nationality = '',
        job         = activeJob,
        jobGrade    = activeRank,
        licences    = {},
        fingerprint = str(meta.fingerprint),
        bloodtype   = str(meta.bloodtype),
        callsign    = str(meta.callsign),
    }
end

---Builds the normalised citizen shape from a VFW `characters` row (phone joined from
---`character_phones`). `licenses` is a JSON list of { type, label }.
---@param row table
---@return table citizen
local function vfwCitizen(row)
    local first = str(row.firstname)
    local last  = str(row.lastname)
    local name  = str(first .. ' ' .. last)
    local meta  = decode(row.metadata)

    local licences = {}
    for _, lic in ipairs(decode(row.licenses)) do
        if type(lic) == 'table' and type(lic.type) == 'string' then
            -- Same folding as the ESX path: every driving permit reads as `driver`.
            licences[#licences + 1] = lic.type:sub(1, 5) == 'drive' and 'driver' or lic.type
        end
    end

    return {
        citizenid   = row.identifier,
        name        = name ~= '' and name or row.identifier,
        firstname   = first,
        lastname    = last,
        dob         = str(row.dateofbirth),
        sex         = str(row.sex),
        phone       = str(row.phone),
        nationality = '',
        job         = str(row.job),
        jobGrade    = tonumber(row.job_grade) or 0,
        licences    = licences,
        fingerprint = str(meta.fingerprint),
        bloodtype   = str(meta.bloodtype),
        callsign    = str(meta.callsign),
    }
end

---@type string VFW citizen projection, qualified because `character_phones` is joined in.
local VFW_CITIZEN_COLS = 'c.identifier, c.firstname, c.lastname, c.dateofbirth, c.sex, c.job, c.job_grade, c.licenses, c.metadata, p.phone'
---@type string The join every VFW citizen read goes through. Deleted characters are filtered here.
local VFW_CITIZEN_FROM = 'characters c LEFT JOIN character_phones p ON p.identifier = c.identifier'

---@type string QBCore/QBox citizen projection.
local QB_CITIZEN_COLS = 'citizenid, charinfo, metadata, job'
---@type string ESX citizen projection.
local ESX_CITIZEN_COLS = 'identifier, firstname, lastname, dateofbirth, sex, phone_number, job, job_grade'
---@type string ND citizen projection. `groups` carries the job: ND stores no job column, the active
---one is the held group flagged isJob.
local ND_CITIZEN_COLS = 'charid, firstname, lastname, dob, gender, phonenumber, `groups`, metadata'

---One citizen by their framework identifier, or nil. Read-only.
---@param cid string citizenid on QBCore/QBox, identifier on ESX
---@return table|nil citizen
function records.getCitizen(cid)
    if type(cid) ~= 'string' or cid == '' then return nil end

    if framework.name == 'vfw' then
        local row = MySQL.single.await(
            ('SELECT %s FROM %s WHERE c.identifier = ? AND c.deleted_at IS NULL LIMIT 1')
                :format(VFW_CITIZEN_COLS, VFW_CITIZEN_FROM), { cid })
        return row and vfwCitizen(row) or nil
    end

    if framework.qb then
        local row = MySQL.single.await(
            ('SELECT %s FROM players WHERE citizenid = ? LIMIT 1'):format(QB_CITIZEN_COLS), { cid })
        return row and qbCitizen(row) or nil
    end

    if framework.name == 'nd' then
        local row = MySQL.single.await(
            ('SELECT %s FROM nd_characters WHERE charid = ? LIMIT 1'):format(ND_CITIZEN_COLS),
            { tonumber(cid) })
        return row and ndCitizen(row) or nil
    end

    local have = columnsOf('users')
    local cols = have.metadata and (ESX_CITIZEN_COLS .. ', metadata') or ESX_CITIZEN_COLS
    local row  = MySQL.single.await(
        ('SELECT %s FROM users WHERE identifier = ? LIMIT 1'):format(cols), { cid })
    if not row then return nil end
    local citizen = esxCitizen(row)
    citizen.licences = esxLicences(cid)
    return citizen
end

---Citizen names for a set of identifiers as `{ [citizenid] = name }`. One query, offline
---characters included. Read-only.
---@param cids string[]
---@return table<string, string>
function records.namesFor(cids)
    local out = {}
    if type(cids) ~= 'table' or #cids == 0 then return out end

    local marks = {}
    for i = 1, #cids do marks[i] = '?' end
    local inClause = table.concat(marks, ',')

    if framework.name == 'vfw' then
        local rows = MySQL.query.await(
            ('SELECT identifier, firstname, lastname FROM characters WHERE identifier IN (%s)'):format(inClause), cids) or {}
        for i = 1, #rows do
            local name = str(str(rows[i].firstname) .. ' ' .. str(rows[i].lastname))
            out[rows[i].identifier] = name ~= '' and name or rows[i].identifier
        end
        return out
    end

    if framework.qb then
        local rows = MySQL.query.await(
            ('SELECT citizenid, charinfo FROM players WHERE citizenid IN (%s)'):format(inClause), cids) or {}
        for i = 1, #rows do
            local info = decode(rows[i].charinfo)
            local name = str(str(info.firstname) .. ' ' .. str(info.lastname))
            out[rows[i].citizenid] = name ~= '' and name or rows[i].citizenid
        end
        return out
    end

    if framework.name == 'nd' then
        local ids = {}
        for i = 1, #cids do ids[i] = tonumber(cids[i]) end
        local rows = MySQL.query.await(
            ('SELECT charid, firstname, lastname FROM nd_characters WHERE charid IN (%s)'):format(inClause), ids) or {}
        for i = 1, #rows do
            local cid  = tostring(rows[i].charid)
            local name = str(str(rows[i].firstname) .. ' ' .. str(rows[i].lastname))
            out[cid] = name ~= '' and name or cid
        end
        return out
    end

    local rows = MySQL.query.await(
        ('SELECT identifier, firstname, lastname FROM users WHERE identifier IN (%s)'):format(inClause), cids) or {}
    for i = 1, #rows do
        local name = str(str(rows[i].firstname) .. ' ' .. str(rows[i].lastname))
        out[rows[i].identifier] = name ~= '' and name or rows[i].identifier
    end
    return out
end

---A page of citizens matching a free-text term across first name, last name, identifier and
---phone. A term under two characters returns an empty page rather than the whole server.
---Read-only.
---@param term string search term
---@param page integer 1-based page number
---@param pageSize integer rows per page
---@return table[] rows normalised citizen shapes
---@return integer total matching rows
function records.searchCitizens(term, page, pageSize)
    term = str(term)

    local limit  = math.max(1, math.floor(tonumber(pageSize) or 25))
    local offset = math.max(0, (math.max(1, math.floor(tonumber(page) or 1)) - 1) * limit)
    local like   = '%' .. term:gsub('([%%_\\])', '\\%1') .. '%'
    local browse = #term < MIN_TERM

    if framework.name == 'vfw' then
        local where, args = 'WHERE c.deleted_at IS NULL', {}
        if not browse then
            where = where .. [[
                AND (c.identifier LIKE ? OR c.firstname LIKE ? OR c.lastname LIKE ? OR p.phone LIKE ?)
            ]]
            args = { like, like, like, like }
        end
        local total = MySQL.scalar.await(
            ('SELECT COUNT(*) FROM %s %s'):format(VFW_CITIZEN_FROM, where), args)
        local rows  = MySQL.query.await(
            ('SELECT %s FROM %s %s ORDER BY c.id DESC LIMIT %d OFFSET %d')
                :format(VFW_CITIZEN_COLS, VFW_CITIZEN_FROM, where, limit, offset), args) or {}

        local out = {}
        for i = 1, #rows do out[i] = vfwCitizen(rows[i]) end
        return out, tonumber(total) or 0
    end

    if framework.qb then
        local where, args = '', {}
        if not browse then
            -- COLLATE, because JSON_UNQUOTE hands back utf8mb4_bin: a binary, case-SENSITIVE
            -- collation. Without it `sam` never matches `Samuel` and only citizenid search, which
            -- reads a real column with the table's own collation, appears to work.
            where = [[
                WHERE citizenid LIKE ?
                   OR JSON_UNQUOTE(JSON_EXTRACT(charinfo, '$.firstname')) COLLATE utf8mb4_general_ci LIKE ?
                   OR JSON_UNQUOTE(JSON_EXTRACT(charinfo, '$.lastname'))  COLLATE utf8mb4_general_ci LIKE ?
                   OR JSON_UNQUOTE(JSON_EXTRACT(charinfo, '$.phone'))     COLLATE utf8mb4_general_ci LIKE ?
            ]]
            args = { like, like, like, like }
        end
        local order = citizenOrder('players', 'last_updated', 'citizenid')
        local total = MySQL.scalar.await(('SELECT COUNT(*) FROM players %s'):format(where), args)
        local rows  = MySQL.query.await(
            ('SELECT %s FROM players %s ORDER BY %s LIMIT %d OFFSET %d')
                :format(QB_CITIZEN_COLS, where, order, limit, offset), args) or {}

        local out = {}
        for i = 1, #rows do out[i] = qbCitizen(rows[i]) end
        return out, tonumber(total) or 0
    end

    if framework.name == 'nd' then
        local where, args = '', {}
        if not browse then
            where = 'WHERE charid LIKE ? OR firstname LIKE ? OR lastname LIKE ? OR phonenumber LIKE ?'
            args  = { like, like, like, like }
        end
        local order = citizenOrder('nd_characters', 'charid', 'charid')
        local total = MySQL.scalar.await(
            ('SELECT COUNT(*) FROM nd_characters %s'):format(where), args)
        local rows  = MySQL.query.await(
            ('SELECT %s FROM nd_characters %s ORDER BY %s LIMIT %d OFFSET %d')
                :format(ND_CITIZEN_COLS, where, order, limit, offset), args) or {}

        local out = {}
        for i = 1, #rows do out[i] = ndCitizen(rows[i]) end
        return out, tonumber(total) or 0
    end

    local where, args = '', {}
    if not browse then
        where = 'WHERE identifier LIKE ? OR firstname LIKE ? OR lastname LIKE ? OR phone_number LIKE ?'
        args  = { like, like, like, like }
    end
    local have  = columnsOf('users')
    local cols  = have.metadata and (ESX_CITIZEN_COLS .. ', metadata') or ESX_CITIZEN_COLS
    local order = citizenOrder('users', 'last_seen', 'identifier')
    local total = MySQL.scalar.await(('SELECT COUNT(*) FROM users %s'):format(where), args)
    local rows  = MySQL.query.await(
        ('SELECT %s FROM users %s ORDER BY %s LIMIT %d OFFSET %d')
            :format(cols, where, order, limit, offset), args) or {}

    local out = {}
    for i = 1, #rows do out[i] = esxCitizen(rows[i]) end
    return out, tonumber(total) or 0
end

---Builds the normalised vehicle shape from an ownership row. The model is the chosen column when it
---holds a plain name, else the saved-properties model key (`vehicle` on ESX, `properties` on ND),
---else the row's stored hash - ESX keeps the whole blob under `vehicle`, so a value opening with a
---brace is a row rather than a name. Same rule as garages.lua's modelOf.
---@param row table raw ownership row
---@param modelCol string|nil column carrying the model name
---@return table vehicle
local function vehicleOf(row, modelCol)
    local props = decode(row.vehicle)
    if next(props) == nil then props = decode(row.properties) end
    local model = modelCol and str(row[modelCol]) or ''

    if model:sub(1, 1) == '{' then model = '' end
    if model == '' then model = str(props.model or props.modelName) end
    if model == '' then model = str(row.hash) end

    -- Resolved through the garage bridge's column profile rather than a guess at `garage`/`state`:
    -- which columns hold the garage and its state depends entirely on the garage system running.
    local garage, stored, impound = garages.locationOf(row)

    return {
        plate   = str(row.plate):upper(),
        model   = model,
        owner   = row[VEHICLES.idCol],
        garage  = garage,
        state   = stored and 1 or 0,
        impound = impound,
    }
end

---One vehicle by plate, or nil. The plate is matched case- and space-insensitively because the
---framework stores it exactly as the game formatted it. Read-only.
---@param plate string
---@return table|nil vehicle
function records.vehicleByPlate(plate)
    plate = str(plate):upper()
    if plate == '' then return nil end

    local row = MySQL.single.await(
        ('SELECT * FROM `%s` WHERE REPLACE(UPPER(plate), " ", "") = ? LIMIT 1'):format(VEHICLES.table),
        { (plate:gsub('%s', '')) })
    if not row then return nil end
    return vehicleOf(row, modelColumn())
end

---Every vehicle owned by a citizen. Read-only.
---@param cid string owner identifier
---@return table[] vehicles
function records.vehiclesByOwner(cid)
    if type(cid) ~= 'string' or cid == '' then return {} end

    local rows = MySQL.query.await(
        ('SELECT * FROM `%s` WHERE `%s` = ? ORDER BY plate ASC LIMIT 60'):format(VEHICLES.table, VEHICLES.idCol),
        { cid }) or {}

    local modelCol, out = modelColumn(), {}
    for i = 1, #rows do out[i] = vehicleOf(rows[i], modelCol) end
    return out
end

---A page of vehicles matching a plate or model fragment. A term under two characters is not a
---filter, so the whole fleet is paged back in plate order. Read-only.
---@param term string search term
---@param page integer 1-based page number
---@param pageSize integer rows per page
---@return table[] rows normalised vehicle shapes
---@return integer total matching rows
function records.searchVehicles(term, page, pageSize)
    term = str(term)

    local limit  = math.max(1, math.floor(tonumber(pageSize) or 25))
    local offset = math.max(0, (math.max(1, math.floor(tonumber(page) or 1)) - 1) * limit)
    local like   = '%' .. term:gsub('([%%_\\])', '\\%1') .. '%'

    local modelCol = modelColumn()
    local where, args = '', {}
    if #term >= MIN_TERM then
        if modelCol then
            where = ('WHERE plate LIKE ? OR `%s` LIKE ?'):format(modelCol)
            args  = { like, like }
        else
            where = 'WHERE plate LIKE ?'
            args  = { like }
        end
    end

    local total = MySQL.scalar.await(
        ('SELECT COUNT(*) FROM `%s` %s'):format(VEHICLES.table, where), args)
    local rows = MySQL.query.await(
        ('SELECT * FROM `%s` %s ORDER BY plate ASC LIMIT %d OFFSET %d')
            :format(VEHICLES.table, where, limit, offset), args) or {}

    local out = {}
    for i = 1, #rows do out[i] = vehicleOf(rows[i], modelCol) end
    return out, tonumber(total) or 0
end

return records
